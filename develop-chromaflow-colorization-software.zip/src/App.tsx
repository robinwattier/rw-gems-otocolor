/**
 * ChromaFlow — Main Application Entry
 * Professional 2D Animation Auto-Colorization Software
 * 
 * Architecture: React + Zustand + Canvas API
 * Simulates: Python 3.11 + PyQt6 + PyTorch 2.4 + SAM 2 + RAFT + OpenCV stack
 */

import React, { useEffect } from 'react';
import { TitleBar } from './components/TitleBar';
import { Toolbar } from './components/Toolbar';
import { Canvas } from './components/Canvas';
import { Timeline } from './components/Timeline';
import { RightPanel } from './components/RightPanel';
import { StatusBar } from './components/StatusBar';
import { ToolOptionsBar } from './components/ToolOptionsBar';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ExportDialog } from './components/ExportDialog';
import { useChromaStore } from './store/chromaStore';

// ─── Keyboard Shortcut Handler ─────────────────────────────────────────────

function useKeyboardShortcuts() {
  const {
    setTool,
    setZoom,
    canvas,
    toggleGrid,
    toggleOnionSkin,
    currentFrameIndex,
    setCurrentFrame,
    project,
    markAsKeyframe,
    undo,
    startPropagation,
    currentPhase,
    setShowExportDialog,
    aiProgress,
    learnFromCorrection,
  } = useChromaStore();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when typing in inputs
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as Element).tagName)) return;

      const ctrl = e.ctrlKey || e.metaKey;

      // Tool shortcuts
      if (!ctrl) {
        switch (e.key.toLowerCase()) {
          case 'v': setTool('select'); break;
          case 'b': setTool('brush'); break;
          case 'g': 
            if (!e.shiftKey) { setTool('fill'); }
            else { toggleGrid(); }
            break;
          case 'e': setTool('eraser'); break;
          case 'i': setTool('eyedropper'); break;
          case 'h': setTool('pan'); break;
          case 'z': if (!ctrl) setTool('zoom'); break;
          case 'l': setTool('lasso'); break;
          case 's': setTool('smartFill'); break;
          case 't': setTool('semanticTag'); break;
          case 'o': toggleOnionSkin(); break;
          case 'k': if (project) markAsKeyframe(currentFrameIndex); break;
          case 'arrowleft':
            e.preventDefault();
            setCurrentFrame(Math.max(0, currentFrameIndex - 1));
            break;
          case 'arrowright':
            e.preventDefault();
            setCurrentFrame(Math.min((project?.frames.length ?? 1) - 1, currentFrameIndex + 1));
            break;
          case 'arrowup':
            e.preventDefault();
            setZoom(canvas.zoom * 1.25);
            break;
          case 'arrowdown':
            e.preventDefault();
            setZoom(canvas.zoom * 0.8);
            break;
        }
      }

      // Ctrl shortcuts
      if (ctrl) {
        switch (e.key.toLowerCase()) {
          case 'z': e.preventDefault(); undo(); break;
          case '+':
          case '=': e.preventDefault(); setZoom(canvas.zoom * 1.25); break;
          case '-': e.preventDefault(); setZoom(canvas.zoom * 0.8); break;
          case '0': e.preventDefault(); setZoom(1); break;
          case '1': e.preventDefault(); setZoom(1); break;
          case '2': e.preventDefault(); setZoom(2); break;
          case 'e': e.preventDefault(); setShowExportDialog(true); break;
          case 'p':
            e.preventDefault();
            if (currentPhase === 'propagation' && !aiProgress.isRunning) {
              startPropagation();
            }
            break;
          case 'l':
            e.preventDefault();
            if (currentPhase === 'refinement' && !aiProgress.isRunning) {
              learnFromCorrection(currentFrameIndex);
            }
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    setTool, setZoom, canvas.zoom, toggleGrid, toggleOnionSkin,
    currentFrameIndex, setCurrentFrame, project, markAsKeyframe,
    undo, startPropagation, currentPhase, setShowExportDialog,
    aiProgress.isRunning, learnFromCorrection,
  ]);
}

// ─── Layout Splitter ────────────────────────────────────────────────────────

const VerticalSplitter: React.FC<{
  topHeight: number;
  onResize: (height: number) => void;
  children: [React.ReactNode, React.ReactNode];
}> = ({ topHeight, onResize, children }) => {
  const isDragging = React.useRef(false);
  const startY = React.useRef(0);
  const startHeight = React.useRef(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    startY.current = e.clientY;
    startHeight.current = topHeight;
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging.current) return;
      const delta = e.clientY - startY.current;
      const newHeight = Math.max(60, Math.min(600, startHeight.current + delta));
      onResize(newHeight);
    };
    const handleMouseUp = () => {
      isDragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [onResize]);

  return (
    <div className="flex flex-col" style={{ height: '100%' }}>
      <div style={{ height: topHeight, flexShrink: 0 }} className="overflow-hidden">
        {children[0]}
      </div>
      {/* Splitter handle */}
      <div
        className="flex-shrink-0 h-1 border-t border-[#111] cursor-row-resize hover:border-[#2a6ac8] transition-colors group relative"
        onMouseDown={handleMouseDown}
      >
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-center">
          <div className="h-0.5 w-8 rounded-full bg-[#2a2a2a] group-hover:bg-[#2a6ac8] transition-colors" />
        </div>
      </div>
      <div className="flex-1 overflow-hidden">
        {children[1]}
      </div>
    </div>
  );
};

// ─── Main Application ──────────────────────────────────────────────────────

export default function App() {
  useKeyboardShortcuts();

  const { showWelcome, showExportDialog } = useChromaStore();
  const [timelineHeight] = React.useState(130);

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-[#0d0d0d] text-[#ccc]">

      {/* ── Title / Menu Bar ── */}
      <TitleBar />

      {/* ── Tool Options Bar ── */}
      <ToolOptionsBar />

      {/* ── Main Work Area ── */}
      <div className="flex flex-1 overflow-hidden">

        {/* ── Left Toolbar ── */}
        <Toolbar />

        {/* ── Center: Canvas + Timeline ── */}
        <div className="flex flex-1 flex-col overflow-hidden">
          <VerticalSplitter
            topHeight={window.innerHeight - timelineHeight - 36 - 32 - 24 - 24}
            onResize={() => {}}
          >
            {/* Canvas viewport */}
            <Canvas />
            {/* Timeline */}
            <div style={{ height: timelineHeight }} className="flex-shrink-0 overflow-hidden">
              <Timeline />
            </div>
          </VerticalSplitter>
        </div>

        {/* ── Right Panel ── */}
        <RightPanel />
      </div>

      {/* ── Status Bar ── */}
      <StatusBar />

      {/* ── Overlays ── */}
      {showWelcome && <WelcomeScreen />}
      {showExportDialog && <ExportDialog />}
    </div>
  );
}
