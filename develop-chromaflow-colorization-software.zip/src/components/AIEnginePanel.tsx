/**
 * ChromaFlow — AI Engine Control Panel
 * Workflow phases, model status, propagation control, learning from corrections
 */

import React, { useState } from 'react';
import { useChromaStore, WorkflowPhase } from '../store/chromaStore';

// ─── Phase Step Indicator ─────────────────────────────────────────────────────

const PhaseStep: React.FC<{
  number: number;
  label: string;
  sublabel: string;
  phase: WorkflowPhase;
  currentPhase: WorkflowPhase;
  isCompleted: boolean;
  onClick: () => void;
}> = ({ number, label, sublabel, phase, currentPhase, isCompleted, onClick }) => {
  const isActive = phase === currentPhase;
  return (
    <button
      onClick={onClick}
      className={`flex items-start gap-3 rounded-lg p-3 text-left transition-all border ${
        isActive
          ? 'border-[#2a6ac8] bg-[#1a3a6a] bg-opacity-40'
          : isCompleted
          ? 'border-[#2ECC71] border-opacity-30 bg-[#1a3a1a] bg-opacity-20 hover:bg-opacity-30'
          : 'border-[#2a2a2a] hover:border-[#3a3a3a] hover:bg-[#1e1e1e]'
      }`}
    >
      {/* Number badge */}
      <div
        className={`flex-shrink-0 flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold ${
          isActive
            ? 'bg-[#2a6ac8] text-white'
            : isCompleted
            ? 'bg-[#2ECC71] text-black'
            : 'bg-[#2a2a2a] text-[#555]'
        }`}
      >
        {isCompleted && !isActive ? '✓' : number}
      </div>
      <div>
        <div className={`text-[12px] font-semibold ${isActive ? 'text-[#7ab4ff]' : isCompleted ? 'text-[#2ECC71]' : 'text-[#666]'}`}>
          {label}
        </div>
        <div className="text-[10px] text-[#444] mt-0.5">{sublabel}</div>
      </div>
    </button>
  );
};

// ─── Model Status Card ────────────────────────────────────────────────────────

const ModelStatusCard: React.FC<{
  name: string;
  version: string;
  status: 'loading' | 'ready' | 'error' | 'idle';
  vram: string;
  description: string;
}> = ({ name, version, status, vram, description }) => {
  const statusConfig = {
    loading: { color: '#F39C12', dot: 'animate-pulse bg-[#F39C12]', text: 'Loading...' },
    ready: { color: '#2ECC71', dot: 'bg-[#2ECC71]', text: 'Ready' },
    error: { color: '#E74C3C', dot: 'bg-[#E74C3C]', text: 'Error' },
    idle: { color: '#555', dot: 'bg-[#333]', text: 'Not Loaded' },
  };
  const cfg = statusConfig[status];

  return (
    <div className="rounded border border-[#2a2a2a] bg-[#161616] p-2.5">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-1.5">
            <div className={`h-2 w-2 rounded-full flex-shrink-0 ${cfg.dot}`} />
            <span className="text-[12px] font-semibold text-[#ccc]">{name}</span>
            <span className="text-[9px] text-[#444] font-mono bg-[#1e1e1e] px-1 rounded">{version}</span>
          </div>
          <div className="text-[10px] text-[#555] mt-0.5 ml-3.5">{description}</div>
        </div>
        <div className="text-right flex-shrink-0 ml-2">
          <div className="text-[10px] font-medium" style={{ color: cfg.color }}>{cfg.text}</div>
          <div className="text-[9px] text-[#444]">{vram} VRAM</div>
        </div>
      </div>
      {status === 'idle' && (
        <button className="mt-2 w-full rounded border border-[#2a2a2a] py-1 text-[10px] text-[#555] hover:border-[#2a6ac8] hover:text-[#7ab4ff] transition-colors">
          Load Model
        </button>
      )}
    </div>
  );
};

// ─── Progress Bar ─────────────────────────────────────────────────────────────

const AIProgressBar: React.FC = () => {
  const { aiProgress, cancelPropagation } = useChromaStore();

  if (!aiProgress.isRunning && aiProgress.percentage === 0) return null;

  const phaseColors: Record<string, string> = {
    analyzing: '#3498DB',
    segmenting: '#9B59B6',
    colorizing: '#FF5733',
    propagating: '#2ECC71',
    refining: '#F39C12',
    idle: '#555',
  };

  const color = phaseColors[aiProgress.phase] ?? '#555';

  return (
    <div className="rounded border border-[#2a2a2a] bg-[#161616] p-3">
      {/* Status header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          {aiProgress.isRunning && (
            <div className="flex gap-0.5">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="h-1.5 w-1.5 rounded-full animate-bounce"
                  style={{ backgroundColor: color, animationDelay: `${i * 0.1}s` }}
                />
              ))}
            </div>
          )}
          <span className="text-[11px] font-semibold capitalize" style={{ color }}>
            {aiProgress.phase === 'idle' ? 'Complete' : aiProgress.phase}
          </span>
        </div>
        {aiProgress.isRunning && (
          <button
            onClick={cancelPropagation}
            className="text-[10px] text-[#E74C3C] hover:text-[#FF6B6B] transition-colors"
          >
            Cancel
          </button>
        )}
      </div>

      {/* Message */}
      <div className="text-[10px] text-[#888] mb-2 min-h-4">{aiProgress.message}</div>

      {/* Progress bar */}
      <div className="relative h-2 w-full rounded-full bg-[#1a1a1a] overflow-hidden">
        <div
          className="absolute left-0 top-0 h-full rounded-full transition-all duration-300"
          style={{ width: `${aiProgress.percentage}%`, backgroundColor: color }}
        />
        {/* Shimmer */}
        {aiProgress.isRunning && (
          <div
            className="absolute top-0 h-full w-16 rounded-full opacity-50"
            style={{
              background: `linear-gradient(90deg, transparent, ${color}88, transparent)`,
              animation: 'shimmer 1.5s infinite',
              left: `${Math.min(aiProgress.percentage - 10, 80)}%`,
            }}
          />
        )}
      </div>

      {/* Frame counter */}
      {aiProgress.totalFrames > 0 && (
        <div className="flex justify-between mt-1.5 text-[10px] text-[#444] font-mono">
          <span>Frame {aiProgress.currentFrame} / {aiProgress.totalFrames}</span>
          <span>{aiProgress.percentage}%</span>
        </div>
      )}
    </div>
  );
};

// ─── Phase 1: Ingestion ───────────────────────────────────────────────────────

const IngestionPhase: React.FC = () => {
  const { project, markAsKeyframe, currentFrameIndex, setPhase } = useChromaStore();
  const [learningProgress, setLearningProgress] = useState(0);
  const [isLearning, setIsLearning] = useState(false);

  if (!project) return null;

  const keyframes = project.frames.filter((f) => f.isKeyframe);

  const startFewShotLearning = () => {
    setIsLearning(true);
    let pct = 0;
    const interval = setInterval(() => {
      pct += Math.random() * 18;
      if (pct >= 100) {
        clearInterval(interval);
        setLearningProgress(100);
        setIsLearning(false);
      } else {
        setLearningProgress(pct);
      }
    }, 200);
  };

  return (
    <div className="space-y-3">
      <div className="rounded border border-[#2a2a2a] bg-[#161616] p-3">
        <h4 className="text-[11px] font-semibold text-[#888] uppercase tracking-wider mb-2">
          Import Line Art
        </h4>
        <div className="space-y-1.5">
          <button className="flex w-full items-center gap-2 rounded border border-dashed border-[#2a2a2a] p-2.5 text-left transition-colors hover:border-[#2a6ac8] hover:bg-[#1a3a6a] hover:bg-opacity-20">
            <svg viewBox="0 0 20 20" width={16} height={16} fill="none" stroke="#555" strokeWidth={1.5}>
              <rect x="2" y="4" width="16" height="12" rx="2" />
              <path d="M7 8h6M7 12h4" />
            </svg>
            <div>
              <div className="text-[11px] text-[#666]">Import PNG Sequence…</div>
              <div className="text-[9px] text-[#444]">frame_0001.png, frame_0002.png…</div>
            </div>
          </button>
          <button className="flex w-full items-center gap-2 rounded border border-dashed border-[#2a2a2a] p-2.5 text-left transition-colors hover:border-[#2a6ac8] hover:bg-[#1a3a6a] hover:bg-opacity-20">
            <svg viewBox="0 0 20 20" width={16} height={16} fill="none" stroke="#555" strokeWidth={1.5}>
              <rect x="2" y="4" width="16" height="12" rx="2" />
              <path d="M8 8l6 4-6 4V8z" />
            </svg>
            <div>
              <div className="text-[11px] text-[#666]">Import Video (MP4, MOV)…</div>
              <div className="text-[9px] text-[#444]">Extracted via FFmpeg</div>
            </div>
          </button>
        </div>
      </div>

      <div className="rounded border border-[#2a2a2a] bg-[#161616] p-3">
        <h4 className="text-[11px] font-semibold text-[#888] uppercase tracking-wider mb-2">
          Keyframe Labeling
        </h4>
        <p className="text-[10px] text-[#555] mb-2">
          Double-click frames in the timeline to mark as keyframes, then color them manually.
          The AI will learn your color rules from these examples.
        </p>
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] text-[#888]">{keyframes.length} keyframes labeled</span>
          <button
            onClick={() => markAsKeyframe(currentFrameIndex)}
            className="flex items-center gap-1 rounded border border-[#FFD700] border-opacity-40 px-2 py-0.5 text-[10px] text-[#FFD700] hover:bg-[#FFD700] hover:bg-opacity-10 transition-colors"
          >
            <svg viewBox="0 0 12 12" width={9} height={9} fill="currentColor">
              <path d="M6 1l1.5 3 3.5.5-2.5 2.5.5 3.5L6 9l-3 1.5.5-3.5L1 4.5 4.5 4z" />
            </svg>
            Toggle Keyframe
          </button>
        </div>
        {keyframes.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {keyframes.map((f) => (
              <div
                key={f.id}
                className="rounded bg-[#2a2a1a] border border-[#FFD700] border-opacity-30 px-1.5 py-0.5 text-[9px] text-[#FFD700] font-mono"
              >
                F{f.index + 1}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded border border-[#2a2a2a] bg-[#161616] p-3">
        <h4 className="text-[11px] font-semibold text-[#888] uppercase tracking-wider mb-2">
          Few-Shot Learning
        </h4>
        <p className="text-[10px] text-[#555] mb-2">
          After coloring keyframes and assigning palette tags, run Few-Shot Learning to train the model on your character's color rules.
        </p>
        {isLearning ? (
          <div className="space-y-2">
            <div className="text-[10px] text-[#F39C12]">
              Learning character color rules…
            </div>
            <div className="h-1.5 w-full rounded-full bg-[#1a1a1a] overflow-hidden">
              <div
                className="h-full rounded-full bg-[#F39C12] transition-all duration-200"
                style={{ width: `${learningProgress}%` }}
              />
            </div>
            <div className="text-[9px] text-[#444] font-mono">{Math.round(learningProgress)}%</div>
          </div>
        ) : learningProgress >= 100 ? (
          <div className="flex items-center gap-2 text-[#2ECC71] text-[11px]">
            <svg viewBox="0 0 16 16" width={14} height={14} fill="none" stroke="currentColor" strokeWidth={1.5}>
              <circle cx="8" cy="8" r="6" />
              <path d="M5 8l2 2 4-4" />
            </svg>
            Model trained on {keyframes.length} examples
          </div>
        ) : (
          <button
            onClick={startFewShotLearning}
            disabled={keyframes.length < 1}
            className="w-full rounded bg-[#533483] py-2 text-[11px] font-semibold text-white hover:bg-[#6342a0] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Run Few-Shot Learning ({keyframes.length} examples)
          </button>
        )}
      </div>

      {learningProgress >= 100 && (
        <button
          onClick={() => setPhase('propagation')}
          className="w-full rounded bg-[#2a6ac8] py-2 text-[12px] font-semibold text-white hover:bg-[#3a7ad8] transition-colors"
        >
          Proceed to Phase 2: Propagation →
        </button>
      )}
    </div>
  );
};

// ─── Phase 2: Propagation ─────────────────────────────────────────────────────

const PropagationPhase: React.FC = () => {
  const { project, aiProgress, startPropagation, setPhase } = useChromaStore();

  if (!project) return null;

  const colorized = project.frames.filter((f) => f.isColorized).length;
  const total = project.frames.length;
  const pending = total - colorized;
  const avgConfidence = project.frames
    .filter((f) => f.isColorized && f.confidence > 0)
    .reduce((sum, f, _, arr) => sum + f.confidence / arr.length, 0);

  return (
    <div className="space-y-3">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Total', value: total, color: '#888' },
          { label: 'Colorized', value: colorized, color: '#2ECC71' },
          { label: 'Pending', value: pending, color: pending > 0 ? '#F39C12' : '#555' },
        ].map(({ label, value, color }) => (
          <div key={label} className="rounded border border-[#2a2a2a] bg-[#161616] p-2 text-center">
            <div className="text-[18px] font-bold font-mono" style={{ color }}>{value}</div>
            <div className="text-[9px] text-[#444]">{label}</div>
          </div>
        ))}
      </div>

      {avgConfidence > 0 && (
        <div className="flex items-center gap-2 rounded border border-[#2a2a2a] bg-[#161616] p-2">
          <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="#2ECC71" strokeWidth={1.5}>
            <path d="M8 2l1.5 3 3.5.5-2.5 2.5.5 3.5L8 10.5 5 12l.5-3.5L3 6l3.5-.5z" />
          </svg>
          <span className="text-[11px] text-[#888]">
            Avg confidence: <span className="text-[#2ECC71] font-semibold font-mono">{Math.round(avgConfidence * 100)}%</span>
          </span>
        </div>
      )}

      {/* Settings */}
      <div className="rounded border border-[#2a2a2a] bg-[#161616] p-3 space-y-2">
        <h4 className="text-[11px] font-semibold text-[#888] uppercase tracking-wider">Propagation Settings</h4>
        {[
          { label: 'Temporal Consistency', type: 'toggle', value: true },
          { label: 'Anti-Flicker Filter', type: 'toggle', value: true },
          { label: 'Gap Closing', type: 'toggle', value: true },
          { label: 'Palette Enforcement', type: 'toggle', value: true },
        ].map((setting) => (
          <div key={setting.label} className="flex items-center justify-between">
            <span className="text-[11px] text-[#666]">{setting.label}</span>
            <div
              className="flex h-4 w-7 items-center rounded-full transition-colors cursor-pointer"
              style={{ backgroundColor: setting.value ? '#2a6ac8' : '#2a2a2a' }}
            >
              <div
                className="h-3 w-3 rounded-full bg-white shadow transition-transform"
                style={{ transform: setting.value ? 'translateX(14px)' : 'translateX(2px)' }}
              />
            </div>
          </div>
        ))}
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-[#666]">Optical Flow Model</span>
          <select className="rounded bg-[#111] border border-[#2a2a2a] px-1.5 py-0.5 text-[10px] text-[#888]">
            <option>RAFT (High Quality)</option>
            <option>GMFlow (Fast)</option>
            <option>FlowNet (Balanced)</option>
          </select>
        </div>
      </div>

      {/* Progress display */}
      <AIProgressBar />

      {/* Action button */}
      {!aiProgress.isRunning ? (
        <div className="space-y-2">
          <button
            onClick={startPropagation}
            disabled={pending === 0}
            className="w-full rounded bg-gradient-to-r from-[#2a6ac8] to-[#533483] py-3 text-[13px] font-bold text-white hover:from-[#3a7ad8] hover:to-[#6342a0] disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-lg"
          >
            {pending === 0 ? '✓ All Frames Colorized' : `⚡ Propagate Colors (${pending} frames)`}
          </button>
          {colorized > 0 && pending === 0 && (
            <button
              onClick={() => setPhase('refinement')}
              className="w-full rounded border border-[#2ECC71] border-opacity-40 py-2 text-[12px] font-semibold text-[#2ECC71] hover:bg-[#2ECC71] hover:bg-opacity-10 transition-colors"
            >
              Proceed to Phase 3: Refinement →
            </button>
          )}
        </div>
      ) : (
        <div className="text-center text-[11px] text-[#555]">
          Propagation running… use Cancel to stop
        </div>
      )}
    </div>
  );
};

// ─── Phase 3: Refinement ──────────────────────────────────────────────────────

const RefinementPhase: React.FC = () => {
  const { project, currentFrameIndex, learnFromCorrection, aiProgress } = useChromaStore();

  if (!project) return null;

  const currentFrame = project.frames[currentFrameIndex];
  const corrections = project.frames.filter((f) => f.hasCorrections);

  return (
    <div className="space-y-3">
      <div className="rounded border border-[#533483] border-opacity-40 bg-[#1a1530] bg-opacity-40 p-3">
        <h4 className="text-[11px] font-semibold text-[#9B59B6] uppercase tracking-wider mb-1">Human-in-the-Loop</h4>
        <p className="text-[10px] text-[#555]">
          Paint corrections directly on any frame. Use "Learn from Correction" to update the model and propagate your fix forward.
        </p>
      </div>

      {/* Current frame info */}
      <div className="rounded border border-[#2a2a2a] bg-[#161616] p-2.5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] text-[#888]">Current Frame: <span className="text-[#ccc] font-mono">F{currentFrameIndex + 1}</span></span>
          {currentFrame?.isColorized && (
            <span
              className="text-[10px] font-semibold"
              style={{
                color: (currentFrame.confidence ?? 0) > 0.9 ? '#2ECC71' : (currentFrame.confidence ?? 0) > 0.75 ? '#F39C12' : '#E74C3C',
              }}
            >
              {Math.round((currentFrame.confidence ?? 0) * 100)}% confidence
            </span>
          )}
        </div>

        {/* Confidence visualization */}
        {currentFrame?.isColorized && (
          <div className="h-1.5 w-full rounded-full bg-[#1a1a1a] overflow-hidden mb-2">
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${(currentFrame.confidence ?? 0) * 100}%`,
                backgroundColor: (currentFrame.confidence ?? 0) > 0.9 ? '#2ECC71' : (currentFrame.confidence ?? 0) > 0.75 ? '#F39C12' : '#E74C3C',
              }}
            />
          </div>
        )}

        {aiProgress.isRunning && aiProgress.phase === 'refining' ? (
          <AIProgressBar />
        ) : (
          <button
            onClick={() => learnFromCorrection(currentFrameIndex)}
            disabled={!currentFrame?.isColorized}
            className="w-full rounded border border-[#9B59B6] border-opacity-40 py-2 text-[11px] font-semibold text-[#9B59B6] hover:bg-[#9B59B6] hover:bg-opacity-10 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            🧠 Learn from Correction → Propagate Forward
          </button>
        )}
      </div>

      {/* Correction stats */}
      {corrections.length > 0 && (
        <div className="rounded border border-[#2a2a2a] bg-[#161616] p-2.5">
          <h4 className="text-[11px] font-semibold text-[#888] uppercase tracking-wider mb-2">Correction History</h4>
          <div className="space-y-1">
            {corrections.map((f) => (
              <div key={f.id} className="flex items-center justify-between text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="h-1.5 w-1.5 rounded-full bg-[#E91E63]" />
                  <span className="text-[#888]">Frame {f.index + 1}</span>
                </div>
                <button className="text-[#444] hover:text-[#9B59B6] transition-colors">Re-learn</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Batch re-propagation */}
      <div className="rounded border border-[#2a2a2a] bg-[#161616] p-2.5">
        <h4 className="text-[11px] font-semibold text-[#888] uppercase tracking-wider mb-2">Re-Propagation</h4>
        <div className="space-y-1.5">
          <button className="w-full rounded border border-[#2a2a2a] py-1.5 text-[10px] text-[#666] hover:border-[#2a6ac8] hover:text-[#7ab4ff] transition-colors">
            Re-Propagate from Current Frame →
          </button>
          <button className="w-full rounded border border-[#2a2a2a] py-1.5 text-[10px] text-[#666] hover:border-[#2a6ac8] hover:text-[#7ab4ff] transition-colors">
            Re-Propagate All Frames
          </button>
          <button className="w-full rounded border border-[#2a2a2a] py-1.5 text-[10px] text-[#666] hover:border-[#F39C12] hover:text-[#F39C12] transition-colors">
            Re-Propagate Low Confidence Only (&lt;80%)
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Main AI Engine Panel ─────────────────────────────────────────────────────

export const AIEnginePanel: React.FC = () => {
  const { currentPhase, setPhase, project, aiProgress } = useChromaStore();

  const phases: { phase: WorkflowPhase; label: string; sublabel: string }[] = [
    { phase: 'ingestion', label: 'Phase 1: Ingestion', sublabel: 'Import & few-shot learning' },
    { phase: 'propagation', label: 'Phase 2: Propagation', sublabel: 'AI colorizes all frames' },
    { phase: 'refinement', label: 'Phase 3: Refinement', sublabel: 'Human-in-the-loop fixes' },
  ];

  const phaseOrder: WorkflowPhase[] = ['ingestion', 'propagation', 'refinement'];
  const currentPhaseIndex = phaseOrder.indexOf(currentPhase);

  return (
    <div className="flex h-full flex-col bg-[#1e1e1e] text-[12px]">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#111] px-3 py-2 flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className={`h-2 w-2 rounded-full ${aiProgress.isRunning ? 'bg-[#2a6ac8] animate-pulse' : 'bg-[#333]'}`} />
          <span className="text-[11px] font-semibold text-[#888] uppercase tracking-wider">AI Engine</span>
        </div>
        <div className="flex items-center gap-1 text-[9px] text-[#444]">
          <span>GPU</span>
          <div className="h-1 w-12 rounded-full bg-[#1a1a1a] overflow-hidden">
            <div className="h-full w-1/3 rounded-full bg-[#2a6ac8] opacity-60" />
          </div>
          <span>32%</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-2" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>

        {/* Phase steps */}
        <div className="space-y-1">
          {phases.map((p, i) => (
            <PhaseStep
              key={p.phase}
              number={i + 1}
              label={p.label}
              sublabel={p.sublabel}
              phase={p.phase}
              currentPhase={currentPhase}
              isCompleted={i < currentPhaseIndex}
              onClick={() => project && setPhase(p.phase)}
            />
          ))}
        </div>

        <div className="border-t border-[#111] pt-2">
          {/* Active phase content */}
          {currentPhase === 'ingestion' && <IngestionPhase />}
          {currentPhase === 'propagation' && <PropagationPhase />}
          {currentPhase === 'refinement' && <RefinementPhase />}
        </div>

        {/* Model status section */}
        <div className="border-t border-[#111] pt-2 space-y-1.5">
          <h4 className="text-[10px] font-semibold text-[#555] uppercase tracking-wider">Model Status</h4>
          <ModelStatusCard
            name="SAM 2"
            version="2.1"
            status={aiProgress.modelStatus.sam2}
            vram="4.2 GB"
            description="Segment Anything 2 — spatial understanding"
          />
          <ModelStatusCard
            name="RAFT"
            version="1.0"
            status={aiProgress.modelStatus.opticalFlow}
            vram="1.8 GB"
            description="Optical flow for temporal consistency"
          />
          <ModelStatusCard
            name="Few-Shot"
            version="custom"
            status={aiProgress.modelStatus.fewShot}
            vram="0.8 GB"
            description="Character-specific color learning"
          />
        </div>
      </div>
    </div>
  );
};
