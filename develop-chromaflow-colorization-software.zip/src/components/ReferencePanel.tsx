/**
 * ChromaFlow — Reference Panel
 * Model sheets, turnarounds, color keys for reference during colorization
 */

import React, { useState } from 'react';


interface ReferenceImage {
  id: string;
  name: string;
  type: 'turnaround' | 'model_sheet' | 'color_key' | 'reference';
  gradient: string;
}

const MOCK_REFERENCES: ReferenceImage[] = [
  { id: 'ref-1', name: 'Kaito — Front View', type: 'turnaround', gradient: 'linear-gradient(135deg, #1A1A2E 0%, #FF5733 50%, #2E8B57 100%)' },
  { id: 'ref-2', name: 'Kaito — Side View', type: 'turnaround', gradient: 'linear-gradient(45deg, #1A1A2E 0%, #2E8B57 60%, #FF5733 100%)' },
  { id: 'ref-3', name: 'Kaito — Back View', type: 'turnaround', gradient: 'linear-gradient(135deg, #2C3E50 0%, #1A1A2E 50%, #FF5733 100%)' },
  { id: 'ref-4', name: 'Color Key Sheet', type: 'color_key', gradient: 'linear-gradient(45deg, #FF5733, #2E8B57, #3498DB, #FFD700)' },
  { id: 'ref-5', name: 'Expressions Sheet', type: 'model_sheet', gradient: 'linear-gradient(135deg, #1A1A2E 30%, #2E8B57 100%)' },
];

export const ReferencePanel: React.FC = () => {
  const [selectedRef, setSelectedRef] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);

  return (
    <div className="flex h-full flex-col bg-[#1e1e1e] text-[12px]">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#111] px-2 py-1.5 flex-shrink-0">
        <span className="text-[11px] font-semibold text-[#888] uppercase tracking-wider">Reference</span>
        <button
          className="flex h-5 w-5 items-center justify-center rounded text-[#555] hover:bg-[#2a2a2a] hover:text-[#ccc]"
          title="Add Reference Image"
        >
          <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
            <path d="M6 2v8M2 6h8" />
          </svg>
        </button>
      </div>

      {/* Reference grid */}
      <div className="flex-1 overflow-y-auto p-2 grid grid-cols-2 gap-1.5 content-start" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>
        {MOCK_REFERENCES.map((ref) => (
          <button
            key={ref.id}
            onClick={() => setSelectedRef(ref.id === selectedRef ? null : ref.id)}
            className={`group relative rounded overflow-hidden border transition-all ${
              selectedRef === ref.id
                ? 'border-[#2a6ac8]'
                : 'border-[#2a2a2a] hover:border-[#3a3a3a]'
            }`}
          >
            {/* Simulated image */}
            <div
              className="w-full aspect-video"
              style={{ background: ref.gradient }}
            />
            {/* Label */}
            <div className="bg-[#161616] px-1.5 py-1">
              <div className="text-[9px] text-[#666] truncate">{ref.name}</div>
              <div className="text-[8px] text-[#333] capitalize">{ref.type.replace('_', ' ')}</div>
            </div>
            {/* Selected indicator */}
            {selectedRef === ref.id && (
              <div className="absolute top-1 right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#2a6ac8]">
                <svg viewBox="0 0 8 8" width={6} height={6} fill="none" stroke="white" strokeWidth={1.5}>
                  <path d="M1.5 4l2 2 3-4" />
                </svg>
              </div>
            )}
          </button>
        ))}

        {/* Add reference placeholder */}
        <button className="flex aspect-video flex-col items-center justify-center rounded border border-dashed border-[#2a2a2a] text-center hover:border-[#2a6ac8] transition-colors">
          <svg viewBox="0 0 20 20" width={20} height={20} fill="none" stroke="#333" strokeWidth={1.5}>
            <path d="M10 5v10M5 10h10" />
          </svg>
          <span className="text-[8px] text-[#333] mt-1">Add Reference</span>
        </button>
      </div>

      {/* Selected reference info */}
      {selectedRef && (
        <div className="border-t border-[#111] bg-[#161616] p-2 flex-shrink-0">
          {(() => {
            const ref = MOCK_REFERENCES.find((r) => r.id === selectedRef)!;
            return (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[#ccc]">{ref.name}</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setZoom(Math.max(0.25, zoom - 0.25))}
                      className="text-[#444] hover:text-[#888] text-[10px]"
                    >
                      −
                    </button>
                    <span className="text-[9px] text-[#555] font-mono">{Math.round(zoom * 100)}%</span>
                    <button
                      onClick={() => setZoom(Math.min(4, zoom + 0.25))}
                      className="text-[#444] hover:text-[#888] text-[10px]"
                    >
                      +
                    </button>
                  </div>
                </div>
                <div
                  className="w-full rounded border border-[#2a2a2a] overflow-hidden"
                  style={{ aspectRatio: '16/9', background: ref.gradient, transform: `scale(${zoom})`, transformOrigin: 'top left' }}
                />
                <div className="flex gap-1">
                  <button className="flex-1 rounded border border-[#2a2a2a] py-1 text-[9px] text-[#555] hover:border-[#2a6ac8] hover:text-[#7ab4ff]">
                    Float Window
                  </button>
                  <button className="flex-1 rounded border border-[#2a2a2a] py-1 text-[9px] text-[#555] hover:border-[#E74C3C] hover:text-[#E74C3C]">
                    Remove
                  </button>
                </div>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
};
