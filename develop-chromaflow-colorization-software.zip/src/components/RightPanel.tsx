/**
 * ChromaFlow — Right Side Panel
 * Tabbed panel with: Palette | Layers | AI Engine | Properties | History
 */

import React from 'react';
import { useChromaStore } from '../store/chromaStore';
import { PalettePanel } from './PalettePanel';
import { LayersPanel } from './LayersPanel';
import { AIEnginePanel } from './AIEnginePanel';
import { PropertiesPanel } from './PropertiesPanel';

interface TabDef {
  id: string;
  label: string;
  icon: React.ReactNode;
  component: React.FC;
}



const TABS: TabDef[] = [
  {
    id: 'ai',
    label: 'AI Engine',
    icon: (
      <svg viewBox="0 0 16 16" width={13} height={13} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round">
        <circle cx="8" cy="8" r="6" />
        <path d="M8 5v3l2 1" />
        <circle cx="13" cy="3" r="2" className="fill-current" />
      </svg>
    ),
    component: AIEnginePanel,
  },
  {
    id: 'palette',
    label: 'Palette',
    icon: (
      <svg viewBox="0 0 16 16" width={13} height={13} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round">
        <circle cx="8" cy="8" r="6" />
        <circle cx="6" cy="7" r="1" className="fill-current" />
        <circle cx="10" cy="7" r="1" className="fill-current" />
        <circle cx="8" cy="11" r="1" className="fill-current" />
      </svg>
    ),
    component: PalettePanel,
  },
  {
    id: 'layers',
    label: 'Layers',
    icon: (
      <svg viewBox="0 0 16 16" width={13} height={13} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round">
        <rect x="2" y="11" width="12" height="3" rx="0.5" />
        <rect x="2" y="6.5" width="12" height="3" rx="0.5" />
        <rect x="2" y="2" width="12" height="3" rx="0.5" />
      </svg>
    ),
    component: LayersPanel,
  },
  {
    id: 'properties',
    label: 'Tool',
    icon: (
      <svg viewBox="0 0 16 16" width={13} height={13} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round">
        <circle cx="8" cy="8" r="2" />
        <path d="M8 2v2M8 12v2M2 8h2M12 8h2" />
        <path d="M4.5 4.5l1.4 1.4M10.1 10.1l1.4 1.4M4.5 11.5l1.4-1.4M10.1 5.9l1.4-1.4" />
      </svg>
    ),
    component: PropertiesPanel,
  },
  {
    id: 'history',
    label: 'History',
    icon: (
      <svg viewBox="0 0 16 16" width={13} height={13} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round">
        <path d="M2 8a6 6 0 1 1 2 4.5" />
        <path d="M2 4v4h4" />
        <path d="M8 5v3l2 1" />
      </svg>
    ),
    component: HistoryPanel,
  },
];

function HistoryPanel() {
  const { undoHistory, undo, addHistoryEntry, currentFrameIndex } = useChromaStore();

  const historyItems = [
    { label: 'Fill Region — jacket_main', frame: 3, time: '2:34' },
    { label: 'Brush stroke — hair_shadow', frame: 3, time: '2:31' },
    { label: 'Smart Fill — skin_base', frame: 2, time: '2:28' },
    { label: 'Palette applied — Hero Palette', frame: 0, time: '2:20' },
    { label: 'Keyframe marked — Frame 7', frame: 6, time: '2:15' },
    { label: 'Few-Shot Learning', frame: 0, time: '2:10' },
    { label: 'Import PNG sequence', frame: 0, time: '2:05' },
    ...undoHistory.map((h) => ({ label: h.label, frame: h.frameIndex, time: '—' })),
  ];

  return (
    <div className="flex h-full flex-col bg-[#1e1e1e]">
      <div className="flex items-center justify-between border-b border-[#111] px-2 py-1.5 flex-shrink-0">
        <span className="text-[11px] font-semibold text-[#888] uppercase tracking-wider">History</span>
        <div className="flex items-center gap-1">
          <button
            onClick={undo}
            className="flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] text-[#555] hover:bg-[#2a2a2a] hover:text-[#ccc]"
            title="Undo (Ctrl+Z)"
          >
            <svg viewBox="0 0 12 12" width={9} height={9} fill="none" stroke="currentColor" strokeWidth={1.5}>
              <path d="M2 4h5a3 3 0 0 1 0 6H4" />
              <path d="M2 2v4l2-2-2-2z" />
            </svg>
            Undo
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>
        {historyItems.map((item, i) => (
          <div
            key={i}
            className={`flex items-start gap-2 border-b border-[#111] px-2 py-1.5 cursor-pointer transition-colors hover:bg-[#222] ${i === 0 ? 'bg-[#1a2a3a]' : ''}`}
          >
            <div className="flex-shrink-0 mt-0.5">
              <div className={`h-1.5 w-1.5 rounded-full ${i === 0 ? 'bg-[#2a6ac8]' : 'bg-[#2a2a2a]'}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className={`text-[10px] truncate ${i === 0 ? 'text-[#ccc]' : 'text-[#555]'}`}>{item.label}</div>
              <div className="text-[9px] text-[#333]">F{item.frame + 1} · {item.time}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="border-t border-[#111] flex-shrink-0 p-1.5">
        <button
          onClick={() => addHistoryEntry('Manual paint', currentFrameIndex)}
          className="w-full rounded border border-dashed border-[#2a2a2a] py-1 text-[10px] text-[#444] hover:border-[#2a6ac8] hover:text-[#7ab4ff] transition-colors"
        >
          + Add History Snapshot
        </button>
      </div>
    </div>
  );
}

export const RightPanel: React.FC = () => {
  const { activeRightPanel, setActiveRightPanel, aiProgress } = useChromaStore();

  const activeTab = TABS.find((t) => t.id === activeRightPanel) ?? TABS[0];
  const ActiveComponent = activeTab.component;

  return (
    <div className="flex w-64 flex-shrink-0 flex-col border-l border-[#111] bg-[#1a1a1a]">
      {/* Tab bar */}
      <div className="flex border-b border-[#111] bg-[#161616] flex-shrink-0">
        {TABS.map((tab) => {
          const isActive = tab.id === activeRightPanel;
          const hasAlert = tab.id === 'ai' && aiProgress.isRunning;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveRightPanel(tab.id)}
              title={tab.label}
              className={`relative flex flex-1 flex-col items-center gap-0.5 py-2 px-1 transition-colors ${
                isActive
                  ? 'border-b-2 border-[#2a6ac8] text-[#7ab4ff]'
                  : 'text-[#444] hover:text-[#888] border-b-2 border-transparent'
              }`}
            >
              {tab.icon}
              <span className="text-[8px] leading-none">{tab.label}</span>
              {hasAlert && (
                <div className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-[#2a6ac8] animate-pulse" />
              )}
            </button>
          );
        })}
      </div>

      {/* Panel content */}
      <div className="flex-1 overflow-hidden">
        <ActiveComponent />
      </div>
    </div>
  );
};
