/**
 * ChromaFlow — Layers Panel
 * Non-destructive layer management for color corrections and overrides
 */

import React, { useState } from 'react';
import { useChromaStore, Layer } from '../store/chromaStore';

const EyeIcon: React.FC<{ visible: boolean }> = ({ visible }) => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round">
    {visible ? (
      <>
        <path d="M1 8C2.5 4 13.5 4 15 8" />
        <path d="M1 8C2.5 12 13.5 12 15 8" />
        <circle cx="8" cy="8" r="2" />
      </>
    ) : (
      <>
        <path d="M3 3l10 10" />
        <path d="M8 4C4 4 1.5 7 1.5 8" />
        <path d="M8 12c4 0 6.5-3 6.5-4" />
      </>
    )}
  </svg>
);

const LockIcon: React.FC<{ locked: boolean }> = ({ locked }) => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round">
    {locked ? (
      <>
        <rect x="3" y="7" width="10" height="8" rx="1" />
        <path d="M5 7V5a3 3 0 0 1 6 0v2" />
      </>
    ) : (
      <>
        <rect x="3" y="7" width="10" height="8" rx="1" />
        <path d="M5 7V5a3 3 0 0 1 6 0" />
      </>
    )}
  </svg>
);

const LayerTypeIcon: React.FC<{ type: Layer['type'] }> = ({ type }) => {
  const iconMap: Record<Layer['type'], React.ReactNode> = {
    lineart: (
      <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
        <path d="M2 9C3 6 4 4 6 3S9 3 10 4" />
        <circle cx="3" cy="9" r="1" fill="currentColor" />
      </svg>
    ),
    color: (
      <svg viewBox="0 0 12 12" width={10} height={10} fill="currentColor">
        <circle cx="6" cy="6" r="4" opacity="0.7" />
      </svg>
    ),
    correction: (
      <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
        <path d="M2 6l3 3 5-5" />
      </svg>
    ),
    reference: (
      <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
        <rect x="1" y="1" width="10" height="10" rx="1" />
        <path d="M4 4h4M4 6h4M4 8h2" />
      </svg>
    ),
    group: (
      <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
        <rect x="1" y="3" width="10" height="8" rx="1" />
        <path d="M3 3V2a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1" />
      </svg>
    ),
  };
  return <>{iconMap[type]}</>;
};

const BLEND_MODES = ['normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge', 'color-burn', 'hard-light', 'soft-light', 'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity'];

const LayerRow: React.FC<{
  layer: Layer;
  isActive: boolean;
  onSelect: () => void;
}> = ({ layer, isActive, onSelect }) => {
  const { toggleLayerVisibility } = useChromaStore();

  const typeColorMap: Record<Layer['type'], string> = {
    lineart: '#4FC3F7',
    color: '#A5D6A7',
    correction: '#FFCC80',
    reference: '#CE93D8',
    group: '#90CAF9',
  };

  return (
    <div
      className={`group flex items-center gap-1.5 px-2 py-1.5 cursor-pointer border-b border-[#111] transition-colors ${
        isActive
          ? 'bg-[#1a3a6a] border-l-2 border-l-[#2a6ac8]'
          : 'hover:bg-[#222] border-l-2 border-l-transparent'
      }`}
      onClick={onSelect}
    >
      {/* Visibility toggle */}
      <button
        className={`flex-shrink-0 transition-colors ${layer.visible ? 'text-[#666]' : 'text-[#333]'} hover:text-[#ccc]`}
        onClick={(e) => { e.stopPropagation(); toggleLayerVisibility(layer.id); }}
        title={layer.visible ? 'Hide Layer' : 'Show Layer'}
      >
        <EyeIcon visible={layer.visible} />
      </button>

      {/* Lock */}
      <button
        className={`flex-shrink-0 transition-colors ${layer.locked ? 'text-[#888]' : 'text-[#333]'} hover:text-[#ccc]`}
        onClick={(e) => e.stopPropagation()}
        title={layer.locked ? 'Locked' : 'Unlock'}
      >
        <LockIcon locked={layer.locked} />
      </button>

      {/* Layer type + color indicator */}
      <div
        className="flex-shrink-0 flex items-center justify-center h-5 w-5 rounded-sm"
        style={{ backgroundColor: typeColorMap[layer.type] + '22', color: typeColorMap[layer.type] }}
      >
        <LayerTypeIcon type={layer.type} />
      </div>

      {/* Name */}
      <div className="flex-1 min-w-0">
        <div className={`text-[11px] truncate ${isActive ? 'text-[#eee]' : 'text-[#888]'}`}>
          {layer.name}
        </div>
        <div className="text-[9px] text-[#444] capitalize">{layer.blendMode}</div>
      </div>

      {/* Opacity */}
      <div
        className="flex-shrink-0 text-[10px] font-mono text-[#555] w-7 text-right cursor-pointer hover:text-[#aaa]"
        title="Click to edit opacity"
      >
        {layer.opacity}%
      </div>
    </div>
  );
};

export const LayersPanel: React.FC = () => {
  const { layers, activeLayerId, setActiveLayer, setLayerOpacity } = useChromaStore();
  const [selectedId, setSelectedId] = useState<string | null>(activeLayerId);
  const activeLayer = layers.find((l) => l.id === (selectedId ?? activeLayerId));

  const handleSelect = (id: string) => {
    setSelectedId(id);
    setActiveLayer(id);
  };

  return (
    <div className="flex h-full flex-col bg-[#1e1e1e]">

      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#111] px-2 py-1.5 flex-shrink-0">
        <span className="text-[11px] font-semibold text-[#888] uppercase tracking-wider">Layers</span>
        <div className="flex items-center gap-1">
          <button className="flex h-5 w-5 items-center justify-center rounded text-[#555] hover:bg-[#2a2a2a] hover:text-[#ccc]" title="Add Layer">
            <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}><path d="M6 2v8M2 6h8" /></svg>
          </button>
          <button className="flex h-5 w-5 items-center justify-center rounded text-[#555] hover:bg-[#2a2a2a] hover:text-[#ccc]" title="Add Group">
            <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}><rect x="1" y="3" width="10" height="8" rx="1" /><path d="M3 3V2a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1" /></svg>
          </button>
          <button className="flex h-5 w-5 items-center justify-center rounded text-[#555] hover:bg-[#2a2a2a] hover:text-red-400" title="Delete Layer" onClick={() => {}}>
            <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}><path d="M2 3h8M4 3V2h4v1M5 5v4M7 5v4" /><rect x="3" y="3" width="6" height="7" rx="1" /></svg>
          </button>
        </div>
      </div>

      {/* Layer properties (for active layer) */}
      {activeLayer && (
        <div className="flex-shrink-0 border-b border-[#111] bg-[#161616] px-2 py-1.5 space-y-1.5">
          {/* Blend mode + opacity */}
          <div className="flex items-center gap-2">
            <select
              value={activeLayer.blendMode}
              onChange={() => {}}
              className="flex-1 rounded border border-[#2a2a2a] bg-[#111] px-1 py-0.5 text-[10px] text-[#888] outline-none focus:border-[#2a6ac8]"
            >
              {BLEND_MODES.map((m) => (
                <option key={m} value={m} className="capitalize">{m}</option>
              ))}
            </select>
            <div className="flex items-center gap-1">
              <span className="text-[9px] text-[#444]">Opacity</span>
              <input
                type="range"
                min={0}
                max={100}
                value={activeLayer.opacity}
                onChange={(e) => setLayerOpacity(activeLayer.id, Number(e.target.value))}
                className="w-16 accent-[#2a6ac8]"
                style={{ height: 3 }}
              />
              <span className="text-[10px] text-[#888] font-mono w-7">{activeLayer.opacity}%</span>
            </div>
          </div>
        </div>
      )}

      {/* Layer list */}
      <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>
        {layers.map((layer) => (
          <LayerRow
            key={layer.id}
            layer={layer}
            isActive={layer.id === (selectedId ?? activeLayerId)}
            onSelect={() => handleSelect(layer.id)}
          />
        ))}
      </div>

      {/* Legend */}
      <div className="flex-shrink-0 border-t border-[#111] bg-[#161616] px-2 py-1.5">
        <div className="flex flex-wrap gap-x-3 gap-y-0.5">
          {[
            { type: 'lineart', label: 'Line Art', color: '#4FC3F7' },
            { type: 'color', label: 'Color', color: '#A5D6A7' },
            { type: 'correction', label: 'Correction', color: '#FFCC80' },
          ].map(({ type, label, color }) => (
            <div key={type} className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-sm" style={{ backgroundColor: color }} />
              <span className="text-[9px] text-[#444]">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
