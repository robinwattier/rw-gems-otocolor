/**
 * ChromaFlow — Main Canvas Viewport
 * Professional canvas with zoom/pan/rotate, onion skinning, grid overlay
 */

import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useChromaStore } from '../store/chromaStore';

// Simulated frame artwork generator (canvas-drawn)
const drawFrameArt = (
  ctx: CanvasRenderingContext2D,
  frameIndex: number,
  isColorized: boolean,
  width: number,
  height: number,
  _phase: number
) => {
  ctx.clearRect(0, 0, width, height);

  const cx = width / 2;
  const cy = height / 2;
  const t = frameIndex / 24;
  const wobble = Math.sin(t * Math.PI * 2) * 15;

  // Background gradient (if colorized)
  if (isColorized) {
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, '#1A1A2E');
    grad.addColorStop(0.5, '#16213E');
    grad.addColorStop(1, '#0F3460');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
  } else {
    ctx.fillStyle = '#232323';
    ctx.fillRect(0, 0, width, height);
  }

  // Draw character figure (stick-figure style with animation)
  ctx.save();
  ctx.translate(cx + wobble * 0.3, cy);

  ctx.strokeStyle = isColorized ? '#1a1a2e' : '#e8e8e8';
  ctx.lineWidth = isColorized ? 2.5 : 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  // Body
  const bodyY = -20;
  const legSpread = 20 + Math.abs(wobble) * 0.5;

  // Head
  ctx.beginPath();
  ctx.arc(0, bodyY - 55, 22, 0, Math.PI * 2);
  if (isColorized) {
    ctx.fillStyle = '#2E8B57';
    ctx.fill();
  }
  ctx.stroke();

  // Hair
  if (isColorized) {
    ctx.beginPath();
    ctx.arc(0, bodyY - 70, 18, Math.PI, Math.PI * 2);
    ctx.fillStyle = '#1A1A2E';
    ctx.fill();
    // Hair strand
    ctx.beginPath();
    ctx.moveTo(-5, bodyY - 88);
    ctx.quadraticCurveTo(-15, bodyY - 95, -10, bodyY - 100);
    ctx.strokeStyle = '#1A1A2E';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.lineWidth = isColorized ? 2.5 : 2;
    ctx.strokeStyle = isColorized ? '#1a1a2e' : '#e8e8e8';
  }

  // Torso (jacket)
  ctx.beginPath();
  ctx.moveTo(-20, bodyY - 33);
  ctx.lineTo(-22, bodyY + 30);
  ctx.lineTo(22, bodyY + 30);
  ctx.lineTo(20, bodyY - 33);
  ctx.closePath();
  if (isColorized) {
    ctx.fillStyle = '#FF5733';
    ctx.fill();
  }
  ctx.stroke();

  // Belt
  if (isColorized) {
    ctx.fillStyle = '#2C3E50';
    ctx.fillRect(-22, bodyY + 28, 44, 6);
  }

  // Left arm (with animation)
  const armSwing = wobble * 0.8;
  ctx.beginPath();
  ctx.moveTo(-20, bodyY - 20);
  ctx.quadraticCurveTo(-45 + armSwing, bodyY, -40 + armSwing, bodyY + 30);
  if (isColorized) { ctx.strokeStyle = '#FF5733'; }
  ctx.lineWidth = 8;
  ctx.stroke();
  ctx.lineWidth = isColorized ? 2.5 : 2;
  ctx.strokeStyle = isColorized ? '#1a1a2e' : '#e8e8e8';

  // Right arm
  ctx.beginPath();
  ctx.moveTo(20, bodyY - 20);
  ctx.quadraticCurveTo(45 - armSwing, bodyY, 40 - armSwing, bodyY + 30);
  if (isColorized) { ctx.strokeStyle = '#FF5733'; }
  ctx.lineWidth = 8;
  ctx.stroke();
  ctx.lineWidth = isColorized ? 2.5 : 2;
  ctx.strokeStyle = isColorized ? '#1a1a2e' : '#e8e8e8';

  // Pants
  ctx.beginPath();
  ctx.moveTo(-22, bodyY + 30);
  ctx.lineTo(-legSpread, bodyY + 90);
  ctx.moveTo(22, bodyY + 30);
  ctx.lineTo(legSpread, bodyY + 90);
  if (isColorized) { ctx.strokeStyle = '#2C3E50'; }
  ctx.lineWidth = 14;
  ctx.stroke();
  ctx.lineWidth = isColorized ? 2.5 : 2;
  ctx.strokeStyle = isColorized ? '#1a1a2e' : '#e8e8e8';

  // Shoes
  if (isColorized) {
    ctx.fillStyle = '#1a1a2e';
    ctx.beginPath();
    ctx.ellipse(-legSpread, bodyY + 95, 14, 6, -0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(legSpread, bodyY + 95, 14, 6, 0.2, 0, Math.PI * 2);
    ctx.fill();
  }

  // Eyes
  if (isColorized) {
    ctx.fillStyle = '#ECF0F1';
    ctx.beginPath();
    ctx.ellipse(-8, bodyY - 57, 5, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(8, bodyY - 57, 5, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#3498DB';
    ctx.beginPath();
    ctx.arc(-8, bodyY - 57, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(8, bodyY - 57, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.arc(-8, bodyY - 57, 1.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(8, bodyY - 57, 1.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // Mouth (slight smile variation)
  ctx.strokeStyle = isColorized ? '#1a5e3a' : '#e8e8e8';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, bodyY - 48, 6, 0.2, Math.PI - 0.2);
  ctx.stroke();

  ctx.restore();
};

export const Canvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const {
    canvas: canvasState,
    setZoom,
    setPan,
    currentFrameIndex,
    project,
    activeTool,
    aiProgress,
  } = useChromaStore();

  const [isPanning, setIsPanning] = useState(false);
  const [lastPan, setLastPan] = useState({ x: 0, y: 0 });
  const [hoverPos, setHoverPos] = useState<{ x: number; y: number } | null>(null);
  const [renderTick, setRenderTick] = useState(0);

  // Draw the current frame to canvas
  const renderFrame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !project) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const frame = project.frames[currentFrameIndex];
    if (!frame) return;

    const W = canvas.width;
    const H = canvas.height;

    ctx.clearRect(0, 0, W, H);

    // Onion skin (previous frames)
    if (canvasState.showOnionSkin && currentFrameIndex > 0) {
      for (let i = 1; i <= canvasState.onionSkinFrames; i++) {
        const prevIdx = currentFrameIndex - i;
        if (prevIdx < 0) break;
        const prevFrame = project.frames[prevIdx];
        ctx.save();
        ctx.globalAlpha = canvasState.onionSkinOpacity / i;
        ctx.globalCompositeOperation = 'source-over';
        // Draw tinted previous frame
        ctx.fillStyle = `rgba(100, 160, 255, ${0.15 / i})`;
        drawFrameArt(ctx, prevIdx, prevFrame.isColorized, W, H, 0);
        ctx.restore();
      }
    }

    // Current frame
    drawFrameArt(ctx, currentFrameIndex, frame.isColorized, W, H, 0);

    // Grid overlay
    if (canvasState.showGrid) {
      ctx.save();
      ctx.strokeStyle = 'rgba(255,255,255,0.06)';
      ctx.lineWidth = 0.5;
      const gridSize = 32;
      for (let x = 0; x < W; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }
      for (let y = 0; y < H; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
      }
      // Rule of thirds
      ctx.strokeStyle = 'rgba(255,200,100,0.08)';
      ctx.lineWidth = 1;
      [W / 3, (2 * W) / 3].forEach((x) => {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      });
      [H / 3, (2 * H) / 3].forEach((y) => {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      });
      ctx.restore();
    }

    // Frame status overlay
    if (!frame.isColorized) {
      ctx.save();
      ctx.fillStyle = 'rgba(255,180,0,0.12)';
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }

    // AI confidence indicator
    if (frame.isColorized && frame.confidence > 0) {
      const confColor = frame.confidence > 0.9 ? '#2ECC71' : frame.confidence > 0.75 ? '#F39C12' : '#E74C3C';
      ctx.save();
      ctx.strokeStyle = confColor;
      ctx.lineWidth = 2;
      ctx.strokeRect(1, 1, W - 2, H - 2);
      ctx.restore();
    }
  }, [project, currentFrameIndex, canvasState, renderTick]);

  useEffect(() => {
    renderFrame();
  }, [renderFrame]);

  // Re-render when AI colorizes frames
  useEffect(() => {
    if (aiProgress.isRunning) {
      const interval = setInterval(() => setRenderTick((t) => t + 1), 200);
      return () => clearInterval(interval);
    }
  }, [aiProgress.isRunning]);

  // Mouse wheel zoom
  const handleWheel = useCallback(
    (e: React.WheelEvent) => {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 0.9 : 1.1;
      setZoom(canvasState.zoom * delta);
    },
    [canvasState.zoom, setZoom]
  );

  // Pan handling
  const handleMouseDown = (e: React.MouseEvent) => {
    if (activeTool === 'pan' || e.button === 1 || (e.button === 0 && e.altKey)) {
      setIsPanning(true);
      setLastPan({ x: e.clientX, y: e.clientY });
      e.preventDefault();
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    setHoverPos({ x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY });
    if (isPanning) {
      const dx = e.clientX - lastPan.x;
      const dy = e.clientY - lastPan.y;
      setPan(canvasState.panX + dx, canvasState.panY + dy);
      setLastPan({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseUp = () => setIsPanning(false);

  const currentFrame = project?.frames[currentFrameIndex];

  const getCursor = () => {
    if (isPanning) return 'grabbing';
    switch (activeTool) {
      case 'pan': return 'grab';
      case 'zoom': return 'zoom-in';
      case 'eyedropper': return 'crosshair';
      case 'fill': return 'cell';
      case 'brush': return 'crosshair';
      case 'eraser': return 'cell';
      default: return 'default';
    }
  };

  return (
    <div
      ref={containerRef}
      className="relative flex-1 overflow-hidden bg-[#141414]"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ cursor: getCursor() }}
    >
      {/* Checkerboard background */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            'repeating-conic-gradient(#1c1c1c 0% 25%, #161616 0% 50%)',
          backgroundSize: '20px 20px',
        }}
      />

      {!project ? (
        // No project open
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-6">
          <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-[#1e1e1e] border border-[#2a2a2a]">
            <svg viewBox="0 0 24 24" className="h-10 w-10 text-[#333]" fill="none" stroke="currentColor" strokeWidth={1}>
              <rect x="2" y="2" width="20" height="20" rx="3" />
              <path d="M12 8v8M8 12h8" />
            </svg>
          </div>
          <div className="text-center">
            <p className="text-[#444] text-sm font-medium">No project open</p>
            <p className="text-[#333] text-xs mt-1">Create a new project or load the demo</p>
          </div>
        </div>
      ) : (
        // Canvas viewport
        <div
          className="absolute inset-0 flex items-center justify-center"
          style={{
            transform: `translate(${canvasState.panX}px, ${canvasState.panY}px)`,
          }}
        >
          <div
            className="relative shadow-2xl"
            style={{
              transform: `scale(${canvasState.zoom}) rotate(${canvasState.rotation}deg)`,
              transformOrigin: 'center center',
            }}
          >
            {/* Drop shadow around canvas */}
            <div className="absolute -inset-1 rounded-sm bg-black opacity-60 blur-sm" />

            {/* Main canvas */}
            <canvas
              ref={canvasRef}
              width={640}
              height={360}
              className="relative block"
              style={{ imageRendering: canvasState.zoom >= 2 ? 'pixelated' : 'auto' }}
            />

            {/* Frame indicator badges */}
            {currentFrame?.isKeyframe && (
              <div className="absolute top-2 left-2 flex items-center gap-1 rounded bg-[#FFD700] px-2 py-0.5 text-[10px] font-bold text-black shadow">
                ★ KEYFRAME
              </div>
            )}
            {currentFrame?.isColorized && (
              <div
                className="absolute top-2 right-2 flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-bold text-white shadow"
                style={{
                  backgroundColor:
                    (currentFrame?.confidence ?? 0) > 0.9 ? '#2ECC71' :
                    (currentFrame?.confidence ?? 0) > 0.75 ? '#E67E22' : '#E74C3C',
                }}
              >
                AI {Math.round((currentFrame?.confidence ?? 0) * 100)}%
              </div>
            )}

            {/* Brush cursor overlay */}
            {hoverPos && (activeTool === 'brush' || activeTool === 'eraser') && (
              <div
                className="pointer-events-none absolute rounded-full border border-white opacity-70"
                style={{
                  width: 12,
                  height: 12,
                  left: hoverPos.x - 6,
                  top: hoverPos.y - 6,
                }}
              />
            )}
          </div>
        </div>
      )}

      {/* Bottom status bar */}
      <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between border-t border-[#1a1a1a] bg-[#1a1a1a] bg-opacity-90 px-3 py-1 text-[11px] text-[#555]">
        <div className="flex items-center gap-4">
          <span>
            Zoom: <span className="text-[#888]">{Math.round(canvasState.zoom * 100)}%</span>
          </span>
          <span>
            Rotation: <span className="text-[#888]">{canvasState.rotation}°</span>
          </span>
          {hoverPos && (
            <span>
              Cursor:{' '}
              <span className="text-[#888] font-mono">
                {Math.round(hoverPos.x)}, {Math.round(hoverPos.y)}
              </span>
            </span>
          )}
        </div>
        <div className="flex items-center gap-4">
          {project && (
            <>
              <span>
                Frame: <span className="text-[#888]">{currentFrameIndex + 1}/{project.frames.length}</span>
              </span>
              <span>
                {project.width}×{project.height}
              </span>
            </>
          )}
          <div className="flex items-center gap-1.5">
            <span className={`h-1.5 w-1.5 rounded-full ${aiProgress.isRunning ? 'bg-[#2a6ac8] animate-pulse' : 'bg-[#333]'}`} />
            <span>{aiProgress.isRunning ? `AI: ${aiProgress.message.slice(0, 40)}` : 'AI Idle'}</span>
          </div>
        </div>
      </div>

      {/* Zoom controls */}
      <div className="absolute right-4 bottom-8 flex flex-col gap-1">
        <button
          onClick={() => setZoom(Math.min(32, canvasState.zoom * 1.25))}
          className="flex h-7 w-7 items-center justify-center rounded border border-[#2a2a2a] bg-[#1e1e1e] text-[#666] hover:text-[#ccc] hover:bg-[#2a2a2a]"
        >
          <svg viewBox="0 0 16 16" width={14} height={14} fill="none" stroke="currentColor" strokeWidth={1.5}>
            <circle cx="7" cy="7" r="5" />
            <path d="m13 13-2.5-2.5M7 5v4M5 7h4" />
          </svg>
        </button>
        <button
          onClick={() => setZoom(Math.max(0.05, canvasState.zoom * 0.8))}
          className="flex h-7 w-7 items-center justify-center rounded border border-[#2a2a2a] bg-[#1e1e1e] text-[#666] hover:text-[#ccc] hover:bg-[#2a2a2a]"
        >
          <svg viewBox="0 0 16 16" width={14} height={14} fill="none" stroke="currentColor" strokeWidth={1.5}>
            <circle cx="7" cy="7" r="5" />
            <path d="m13 13-2.5-2.5M5 7h4" />
          </svg>
        </button>
        <button
          onClick={() => { setZoom(1); setPan(0, 0); }}
          className="flex h-7 w-7 items-center justify-center rounded border border-[#2a2a2a] bg-[#1e1e1e] text-[10px] text-[#666] hover:text-[#ccc] hover:bg-[#2a2a2a] font-mono"
        >
          1:1
        </button>
      </div>
    </div>
  );
};
