/**
 * ChromaFlow — Left Toolbar
 * Professional tool palette with all artist tools
 */

import React, { useState } from 'react';
import { useChromaStore, ToolId } from '../store/chromaStore';

interface ToolDef {
  id: ToolId;
  label: string;
  shortcut: string;
  icon: React.ReactNode;
  group?: string;
}

const ToolIcon: React.FC<{ d: string; size?: number }> = ({ d, size = 16 }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

const TOOL_GROUPS: { label: string; tools: ToolDef[] }[] = [
  {
    label: 'Selection',
    tools: [
      {
        id: 'select',
        label: 'Select / Move',
        shortcut: 'V',
        icon: <ToolIcon d="M5 3l14 9-7 1-3 7L5 3z" />,
      },
      {
        id: 'lasso',
        label: 'Lasso Select',
        shortcut: 'L',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 3C7 3 3 7 3 12s4 9 9 9" />
            <path d="M21 12c0-2-1-4-3-5" />
            <path d="M14 20l-2 2-2-2" />
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Paint',
    tools: [
      {
        id: 'brush',
        label: 'Brush',
        shortcut: 'B',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M9.06 11.9l8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08" />
            <path d="M7.07 14.94C5.79 16.22 4 17 2 17l2-7 5.07 5.07-2 2" />
          </svg>
        ),
      },
      {
        id: 'fill',
        label: 'Paint Bucket Fill',
        shortcut: 'G',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 11L8.93 1.93a2.5 2.5 0 0 0-3.54 3.54L15 15" />
            <path d="M19.07 19.07A5 5 0 1 1 12 12" />
            <path d="M18 22a3 3 0 0 0 3-3" />
          </svg>
        ),
      },
      {
        id: 'eraser',
        label: 'Eraser',
        shortcut: 'E',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 20H7L3 16l11-11 7 7-3.5 3.5" />
            <path d="M6.0 11.0L13 18" />
          </svg>
        ),
      },
    ],
  },
  {
    label: 'AI Tools',
    tools: [
      {
        id: 'smartFill',
        label: 'Smart Fill (SAM 2)',
        shortcut: 'S',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2a10 10 0 1 0 10 10" />
            <path d="M12 8v4l3 3" />
            <circle cx="19" cy="5" r="3" className="fill-current" />
          </svg>
        ),
      },
      {
        id: 'semanticTag',
        label: 'Semantic Tag',
        shortcut: 'T',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" />
            <line x1="7" y1="7" x2="7.01" y2="7" />
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Color',
    tools: [
      {
        id: 'eyedropper',
        label: 'Eyedropper / Color Picker',
        shortcut: 'I',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 22l1-1h3l9-9" />
            <path d="M3 21v-3l9-9" />
            <path d="m15 6 3.4-3.4a2.1 2.1 0 1 1 3 3L18 9" />
          </svg>
        ),
      },
    ],
  },
  {
    label: 'Navigation',
    tools: [
      {
        id: 'pan',
        label: 'Pan / Hand Tool',
        shortcut: 'H',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2" />
            <path d="M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2" />
            <path d="M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8" />
            <path d="M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15" />
          </svg>
        ),
      },
      {
        id: 'zoom',
        label: 'Zoom Tool',
        shortcut: 'Z',
        icon: (
          <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
            <line x1="11" y1="8" x2="11" y2="14" />
            <line x1="8" y1="11" x2="14" y2="11" />
          </svg>
        ),
      },
    ],
  },
];

const ToolButton: React.FC<{
  tool: ToolDef;
  isActive: boolean;
  onClick: () => void;
}> = ({ tool, isActive, onClick }) => {
  const [hovered, setHovered] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={onClick}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        title={`${tool.label} (${tool.shortcut})`}
        className={`relative flex h-9 w-9 items-center justify-center rounded transition-all duration-100 ${
          isActive
            ? 'bg-[#2a6ac8] text-white shadow-inner shadow-[#1a4a90]'
            : 'text-[#999] hover:bg-[#2a2a2a] hover:text-[#eee]'
        } ${tool.id === 'smartFill' || tool.id === 'semanticTag' ? (isActive ? '' : 'text-[#5fb8ff] hover:text-[#7dd4ff]') : ''}`}
      >
        {tool.icon}
        {/* AI indicator dot */}
        {(tool.id === 'smartFill' || tool.id === 'semanticTag') && (
          <div className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-[#5fb8ff]" />
        )}
      </button>

      {/* Tooltip */}
      {hovered && (
        <div className="pointer-events-none absolute left-full top-1/2 z-50 ml-2 -translate-y-1/2 whitespace-nowrap rounded border border-[#3a3a3a] bg-[#1e1e1e] px-2 py-1 text-[11px] text-[#ccc] shadow-lg">
          <span className="text-[#fff]">{tool.label}</span>
          <span className="ml-2 rounded bg-[#2a2a2a] px-1 text-[10px] text-[#888]">{tool.shortcut}</span>
        </div>
      )}
    </div>
  );
};

export const Toolbar: React.FC = () => {
  const { activeTool, setTool, foregroundColor, backgroundColor, setForegroundColor, setBackgroundColor, brushSize } =
    useChromaStore();

  return (
    <div className="flex h-full w-12 flex-shrink-0 flex-col items-center border-r border-[#111] bg-[#1e1e1e] py-2 gap-0.5">
      {/* Tool Groups */}
      {TOOL_GROUPS.map((group, gi) => (
        <React.Fragment key={group.label}>
          {gi > 0 && <div className="my-1.5 w-6 border-t border-[#333]" />}
          {group.tools.map((tool) => (
            <ToolButton
              key={tool.id}
              tool={tool}
              isActive={activeTool === tool.id}
              onClick={() => setTool(tool.id)}
            />
          ))}
        </React.Fragment>
      ))}

      {/* Spacer */}
      <div className="flex-1" />

      {/* Brush Size mini-display */}
      <div className="mb-1 flex flex-col items-center gap-0.5">
        <div
          className="rounded-full bg-[#ccc]"
          style={{ width: Math.max(2, Math.min(20, brushSize / 2)), height: Math.max(2, Math.min(20, brushSize / 2)) }}
        />
        <span className="text-[9px] text-[#555] font-mono">{brushSize}px</span>
      </div>

      {/* Color Swatches */}
      <div className="mb-2 relative">
        {/* Background color */}
        <button
          className="absolute bottom-0 right-0 h-5 w-5 rounded-sm border-2 border-[#1e1e1e] shadow"
          style={{ backgroundColor }}
          onClick={() => {}}
          title="Background Color"
        />
        {/* Foreground color */}
        <button
          className="relative z-10 h-6 w-6 rounded-sm border border-[#555] shadow-md"
          style={{ backgroundColor: foregroundColor }}
          onClick={() => {}}
          title="Foreground Color"
        />
        {/* Reset icon */}
        <button
          className="absolute -bottom-2 -right-2 text-[#555] hover:text-[#999]"
          onClick={() => { setForegroundColor('#000000'); setBackgroundColor('#ffffff'); }}
          title="Reset Colors (D)"
        >
          <svg viewBox="0 0 12 12" width={8} height={8} fill="currentColor">
            <path d="M10 2H7V0H2v2H0v7h2v2h7v-2h1V2z M8 8H3V3h5V8z" />
          </svg>
        </button>
      </div>
    </div>
  );
};
