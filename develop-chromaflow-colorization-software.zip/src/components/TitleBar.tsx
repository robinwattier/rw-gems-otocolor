/**
 * ChromaFlow — Title Bar / Menu Bar
 * Professional application title bar with full menu system
 */

import React, { useState } from 'react';
import { useChromaStore } from '../store/chromaStore';

interface MenuItem {
  label?: string;
  shortcut?: string;
  action?: () => void;
  separator?: boolean;
  disabled?: boolean;
  submenu?: MenuItem[];
}

interface MenuDef {
  label: string;
  items: MenuItem[];
}

const MenuDropdown: React.FC<{
  items: MenuItem[];
  onClose: () => void;
}> = ({ items, onClose }) => (
  <div
    className="absolute top-full left-0 z-50 mt-px min-w-52 rounded-sm border border-[#3a3a3a] bg-[#1e1e1e] py-1 shadow-2xl"
    onClick={(e) => e.stopPropagation()}
  >
    {items.map((item, i) =>
      item.separator ? (
        <div key={i} className="my-1 border-t border-[#3a3a3a]" />
      ) : (
        <button
          key={i}
          disabled={item.disabled}
          onClick={() => {
            item.action?.();
            onClose();
          }}
          className={`flex w-full items-center justify-between px-4 py-1.5 text-left text-[13px] transition-colors ${
            item.disabled
              ? 'cursor-not-allowed text-[#555]'
              : 'text-[#ccc] hover:bg-[#2a6ac8] hover:text-white'
          }`}
        >
          <span>{item.label}</span>
          {item.shortcut && (
            <span className="ml-8 text-[11px] text-[#666]">{item.shortcut}</span>
          )}
        </button>
      )
    )}
  </div>
);

export const TitleBar: React.FC = () => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const {
    project,
    setShowExportDialog,
    setShowPreferences,
    loadDemoProject,
    setShowWelcome,
    currentPhase,
    setPhase,
    toggleGrid,
    toggleOnionSkin,
    canvas,
    setZoom,
  } = useChromaStore();

  const menus: MenuDef[] = [
    {
      label: 'File',
      items: [
        { label: 'New Project…', shortcut: 'Ctrl+N', action: () => setShowWelcome(true) },
        { label: 'Open Project…', shortcut: 'Ctrl+O', action: () => loadDemoProject() },
        { label: 'Open Recent', disabled: false, action: () => loadDemoProject() },
        { separator: true },
        { label: 'Save', shortcut: 'Ctrl+S', action: () => {}, disabled: !project },
        { label: 'Save As…', shortcut: 'Ctrl+Shift+S', action: () => {}, disabled: !project },
        { label: 'Save as Template…', action: () => {}, disabled: !project },
        { separator: true },
        { label: 'Import Line Art Sequence…', action: () => {}, disabled: !project },
        { label: 'Import Video…', action: () => {}, disabled: !project },
        { label: 'Import Reference…', action: () => {}, disabled: !project },
        { separator: true },
        { label: 'Export…', shortcut: 'Ctrl+E', action: () => setShowExportDialog(true), disabled: !project },
        { label: 'Export All Frames…', action: () => setShowExportDialog(true), disabled: !project },
        { separator: true },
        { label: 'Project Properties…', action: () => {}, disabled: !project },
        { separator: true },
        { label: 'Preferences…', shortcut: 'Ctrl+,', action: () => setShowPreferences(true) },
        { label: 'Quit ChromaFlow', shortcut: 'Ctrl+Q', action: () => {} },
      ],
    },
    {
      label: 'Edit',
      items: [
        { label: 'Undo', shortcut: 'Ctrl+Z', action: () => {} },
        { label: 'Redo', shortcut: 'Ctrl+Shift+Z', action: () => {} },
        { separator: true },
        { label: 'Cut', shortcut: 'Ctrl+X', action: () => {} },
        { label: 'Copy', shortcut: 'Ctrl+C', action: () => {} },
        { label: 'Paste', shortcut: 'Ctrl+V', action: () => {} },
        { separator: true },
        { label: 'Select All', shortcut: 'Ctrl+A', action: () => {} },
        { label: 'Deselect All', shortcut: 'Ctrl+D', action: () => {} },
        { label: 'Invert Selection', shortcut: 'Ctrl+Shift+I', action: () => {} },
        { separator: true },
        { label: 'Fill Selection with Color', shortcut: 'F', action: () => {} },
        { label: 'Fill with Eyedropper Color', action: () => {} },
      ],
    },
    {
      label: 'View',
      items: [
        { label: 'Zoom In', shortcut: 'Ctrl++', action: () => setZoom(canvas.zoom * 1.25) },
        { label: 'Zoom Out', shortcut: 'Ctrl+-', action: () => setZoom(canvas.zoom * 0.8) },
        { label: 'Fit to Window', shortcut: 'Ctrl+0', action: () => setZoom(1) },
        { label: '100%', shortcut: 'Ctrl+1', action: () => setZoom(1) },
        { label: '200%', shortcut: 'Ctrl+2', action: () => setZoom(2) },
        { separator: true },
        { label: canvas.showGrid ? '✓ Show Grid' : 'Show Grid', shortcut: 'G', action: toggleGrid },
        { label: canvas.showOnionSkin ? '✓ Onion Skinning' : 'Onion Skinning', shortcut: 'O', action: toggleOnionSkin },
        { separator: true },
        { label: 'Timeline', action: () => {} },
        { label: 'Palette Panel', action: () => {} },
        { label: 'Layers Panel', action: () => {} },
        { label: 'Reference Panel', action: () => {} },
        { separator: true },
        { label: 'Full Screen', shortcut: 'F11', action: () => {} },
      ],
    },
    {
      label: 'AI Engine',
      items: [
        {
          label: 'Load SAM 2 Model…',
          action: () => {},
          disabled: !project,
        },
        {
          label: 'Load Optical Flow Model…',
          action: () => {},
          disabled: !project,
        },
        { separator: true },
        {
          label: 'Start Propagation',
          shortcut: 'Ctrl+P',
          action: () => setPhase('propagation'),
          disabled: !project,
        },
        {
          label: 'Learn from Corrections',
          shortcut: 'Ctrl+L',
          action: () => {},
          disabled: !project || currentPhase !== 'refinement',
        },
        { separator: true },
        { label: 'AI Settings…', action: () => setShowPreferences(true) },
        { label: 'Model Benchmarks…', action: () => {} },
        { separator: true },
        { label: 'Clear AI Cache', action: () => {} },
        { label: 'Export TorchScript Model…', action: () => {} },
      ],
    },
    {
      label: 'Palette',
      items: [
        { label: 'New Palette…', action: () => {} },
        { label: 'Duplicate Palette', action: () => {}, disabled: !project },
        { label: 'Delete Palette…', action: () => {}, disabled: !project },
        { separator: true },
        { label: 'Import Palette (.aco)…', action: () => {} },
        { label: 'Import Palette (.ase)…', action: () => {} },
        { label: 'Export Palette (.aco)…', action: () => {}, disabled: !project },
        { separator: true },
        { label: 'Enforce Palette on All Frames', action: () => {}, disabled: !project },
        { label: 'Detect Colors in Frame…', action: () => {}, disabled: !project },
        { separator: true },
        { label: 'Palette Library…', action: () => {} },
      ],
    },
    {
      label: 'Help',
      items: [
        { label: 'ChromaFlow Documentation', action: () => {} },
        { label: 'Keyboard Shortcuts…', action: () => {} },
        { label: 'Tutorial Videos…', action: () => {} },
        { separator: true },
        { label: 'Check for Updates…', action: () => {} },
        { label: 'Report a Bug…', action: () => {} },
        { separator: true },
        { label: 'About ChromaFlow…', action: () => {} },
      ],
    },
  ];

  return (
    <div
      className="relative z-40 flex h-9 flex-shrink-0 items-stretch border-b border-[#111] bg-[#1a1a1a] select-none"
      onClick={() => setActiveMenu(null)}
    >
      {/* App Logo + Name */}
      <div className="flex items-center gap-2 px-4 border-r border-[#2a2a2a]">
        <div className="flex h-5 w-5 items-center justify-center rounded">
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none">
            <circle cx="12" cy="12" r="10" fill="#2a6ac8" />
            <path d="M8 12 Q12 6 16 12 Q12 18 8 12Z" fill="#FF5733" opacity="0.9" />
            <path d="M12 8 Q18 12 12 16 Q6 12 12 8Z" fill="#2E8B57" opacity="0.8" />
            <circle cx="12" cy="12" r="2.5" fill="#fff" />
          </svg>
        </div>
        <span className="text-[12px] font-semibold text-[#ddd] tracking-wide">ChromaFlow</span>
        <span className="text-[10px] text-[#555] font-mono">v1.0</span>
      </div>

      {/* Menu Items */}
      {menus.map((menu) => (
        <div key={menu.label} className="relative" onClick={(e) => e.stopPropagation()}>
          <button
            className={`flex h-full items-center px-3 text-[13px] transition-colors ${
              activeMenu === menu.label
                ? 'bg-[#2a6ac8] text-white'
                : 'text-[#bbb] hover:bg-[#2a2a2a] hover:text-white'
            }`}
            onClick={() => setActiveMenu(activeMenu === menu.label ? null : menu.label)}
            onMouseEnter={() => activeMenu && setActiveMenu(menu.label)}
          >
            {menu.label}
          </button>
          {activeMenu === menu.label && (
            <MenuDropdown items={menu.items} onClose={() => setActiveMenu(null)} />
          )}
        </div>
      ))}

      {/* Project Name in Center */}
      <div className="flex flex-1 items-center justify-center">
        <span className="text-[12px] text-[#666]">
          {project ? `${project.name} — ${project.width}×${project.height} @ ${project.fps}fps` : 'No Project Open'}
        </span>
      </div>

      {/* Window Controls (decorative) */}
      <div className="flex items-center gap-2 px-4 border-l border-[#2a2a2a]">
        <div className="h-3 w-3 rounded-full bg-[#FF5F57] opacity-70 hover:opacity-100 cursor-pointer" />
        <div className="h-3 w-3 rounded-full bg-[#FEBC2E] opacity-70 hover:opacity-100 cursor-pointer" />
        <div className="h-3 w-3 rounded-full bg-[#28C840] opacity-70 hover:opacity-100 cursor-pointer" />
      </div>
    </div>
  );
};
