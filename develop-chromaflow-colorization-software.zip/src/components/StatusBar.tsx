/**
 * ChromaFlow — Status Bar
 * Bottom application status bar with notifications and quick stats
 */

import React from 'react';
import { useChromaStore } from '../store/chromaStore';

export const StatusBar: React.FC = () => {
  const { statusMessage, project, aiProgress, currentPhase } = useChromaStore();

  const phaseColors: Record<string, string> = {
    ingestion: '#F39C12',
    propagation: '#2a6ac8',
    refinement: '#9B59B6',
  };

  const phaseLabels: Record<string, string> = {
    ingestion: 'Phase 1: Ingestion',
    propagation: 'Phase 2: Propagation',
    refinement: 'Phase 3: Refinement',
  };

  return (
    <div className="flex h-6 flex-shrink-0 items-center justify-between border-t border-[#111] bg-[#141414] px-3 text-[10px] text-[#444] select-none">
      {/* Left: status message */}
      <div className="flex items-center gap-3 min-w-0">
        <div className={`flex-shrink-0 h-1.5 w-1.5 rounded-full ${aiProgress.isRunning ? 'bg-[#2a6ac8] animate-pulse' : 'bg-[#2ECC71]'}`} />
        <span className="truncate text-[#666]">{statusMessage}</span>
      </div>

      {/* Center: AI progress (if running) */}
      {aiProgress.isRunning && (
        <div className="flex items-center gap-2 flex-shrink-0 mx-4">
          <div className="h-1 w-32 rounded-full bg-[#1a1a1a] overflow-hidden">
            <div
              className="h-full rounded-full bg-[#2a6ac8] transition-all duration-300"
              style={{ width: `${aiProgress.percentage}%` }}
            />
          </div>
          <span className="text-[#2a6ac8] font-mono">{aiProgress.percentage}%</span>
          <span className="text-[#555]">{aiProgress.message.slice(0, 35)}{aiProgress.message.length > 35 ? '…' : ''}</span>
        </div>
      )}

      {/* Right: project stats */}
      <div className="flex items-center gap-4 flex-shrink-0">
        {project && (
          <>
            <span>
              {project.frames.filter((f) => f.isColorized).length}/{project.frames.length} frames
            </span>
            <span>
              {project.width}×{project.height} @ {project.fps}fps
            </span>
          </>
        )}

        {/* Phase indicator */}
        <div
          className="flex items-center gap-1 rounded-full px-2 py-0.5"
          style={{ backgroundColor: phaseColors[currentPhase] + '22', color: phaseColors[currentPhase] }}
        >
          <div className="h-1 w-1 rounded-full" style={{ backgroundColor: phaseColors[currentPhase] }} />
          <span className="font-medium">{phaseLabels[currentPhase]}</span>
        </div>

        {/* GPU indicator */}
        <div className="flex items-center gap-1">
          <span className="text-[#333]">GPU</span>
          <div className="h-1 w-10 rounded-full bg-[#1a1a1a] overflow-hidden">
            <div className="h-full w-1/3 rounded-full bg-[#2a6ac8] opacity-40" />
          </div>
          <span className="text-[#333]">CUDA</span>
        </div>

        <span className="text-[#2a2a2a]">ChromaFlow v1.0</span>
      </div>
    </div>
  );
};
