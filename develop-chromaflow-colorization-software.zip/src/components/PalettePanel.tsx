/**
 * ChromaFlow — Palette Management Panel
 * Professional color palette system with hex codes, semantic tags, and library management
 */

import React, { useState } from 'react';
import { useChromaStore, ColorSwatch } from '../store/chromaStore';

// ─── Sub-components ──────────────────────────────────────────────────────────

const SwatchContextMenu: React.FC<{
  x: number;
  y: number;
  swatch: ColorSwatch;
  paletteId: string;
  onClose: () => void;
}> = ({ x, y, swatch, paletteId, onClose }) => {
  const { setForegroundColor, setBackgroundColor, deleteSwatch } = useChromaStore();

  const menuItems = [
    { label: 'Set as Foreground', action: () => setForegroundColor(swatch.hex) },
    { label: 'Set as Background', action: () => setBackgroundColor(swatch.hex) },
    { separator: true },
    { label: 'Edit Color…', action: () => {} },
    { label: 'Edit Label…', action: () => {} },
    { label: 'Edit Tag…', action: () => {} },
    { separator: true },
    { label: 'Duplicate Swatch', action: () => {} },
    { label: 'Delete Swatch', action: () => deleteSwatch(paletteId, swatch.id), disabled: false },
    { separator: true },
    { label: `Usage: ${swatch.usageCount} frames`, action: () => {}, disabled: true },
  ];

  return (
    <div
      className="fixed z-50 min-w-44 rounded border border-[#3a3a3a] bg-[#1e1e1e] py-1 shadow-2xl"
      style={{ left: Math.min(x, window.innerWidth - 200), top: Math.min(y, window.innerHeight - 250) }}
    >
      {/* Color preview header */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-[#2a2a2a]">
        <div className="h-6 w-6 rounded-sm border border-[#3a3a3a]" style={{ backgroundColor: swatch.hex }} />
        <div>
          <div className="text-[11px] text-[#ccc] font-medium">{swatch.label}</div>
          <div className="text-[10px] text-[#555] font-mono">{swatch.hex}</div>
        </div>
      </div>
      {menuItems.map((item, i) =>
        item.separator ? (
          <div key={i} className="my-1 border-t border-[#2a2a2a]" />
        ) : (
          <button
            key={i}
            disabled={item.disabled}
            className={`w-full px-3 py-1 text-left text-[12px] transition-colors ${
              item.disabled ? 'text-[#555] cursor-default' : 'text-[#ccc] hover:bg-[#2a6ac8] hover:text-white'
            }`}
            onClick={() => { item.action?.(); onClose(); }}
          >
            {item.label}
          </button>
        )
      )}
    </div>
  );
};

const SwatchItem: React.FC<{
  swatch: ColorSwatch;
  paletteId: string;
  isSelected: boolean;
  onClick: () => void;
}> = ({ swatch, paletteId, isSelected, onClick }) => {
  const { setForegroundColor } = useChromaStore();
  const [hovered, setHovered] = useState(false);
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number } | null>(null);

  return (
    <>
      <div
        className={`relative group rounded-sm cursor-pointer transition-all duration-100 ${
          isSelected ? 'ring-2 ring-[#2a6ac8] ring-offset-1 ring-offset-[#1e1e1e]' : ''
        }`}
        style={{ width: 32, height: 32 }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={() => { onClick(); setForegroundColor(swatch.hex); }}
        onContextMenu={(e) => { e.preventDefault(); setCtxMenu({ x: e.clientX, y: e.clientY }); }}
        title={`${swatch.label}\n${swatch.hex}\nTag: ${swatch.tag}\n${swatch.usageCount} uses`}
      >
        <div
          className="w-full h-full rounded-sm border border-[#2a2a2a]"
          style={{ backgroundColor: swatch.hex }}
        />
        {/* Usage count badge */}
        {swatch.usageCount > 0 && (
          <div className="absolute -top-1 -right-1 hidden group-hover:flex h-3.5 min-w-3.5 items-center justify-center rounded-full bg-[#2a6ac8] px-0.5 text-[8px] text-white font-bold">
            {swatch.usageCount > 99 ? '99+' : swatch.usageCount}
          </div>
        )}
      </div>

      {/* Tooltip */}
      {hovered && (
        <div className="pointer-events-none fixed z-50 rounded border border-[#3a3a3a] bg-[#1e1e1e] px-2 py-1.5 shadow-xl"
          style={{ left: 'auto', top: 'auto' }}>
          <div className="text-[11px] text-[#eee] font-medium">{swatch.label}</div>
          <div className="text-[10px] text-[#888] font-mono">{swatch.hex}</div>
          <div className="text-[10px] text-[#555]">#{swatch.tag}</div>
        </div>
      )}

      {/* Context menu */}
      {ctxMenu && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setCtxMenu(null)} />
          <SwatchContextMenu
            x={ctxMenu.x}
            y={ctxMenu.y}
            swatch={swatch}
            paletteId={paletteId}
            onClose={() => setCtxMenu(null)}
          />
        </>
      )}
    </>
  );
};

// ─── Color Wheel (Simple HSV picker) ─────────────────────────────────────────

const MiniColorPicker: React.FC<{
  value: string;
  onChange: (hex: string) => void;
}> = ({ value, onChange }) => {
  const presets = [
    '#FF5733','#E74C3C','#C0392B','#FF8C69',
    '#FF9F43','#F39C12','#FFD700','#F7DC6F',
    '#2ECC71','#27AE60','#2E8B57','#1B4332',
    '#3498DB','#2980B9','#1A5276','#85C1E9',
    '#9B59B6','#8E44AD','#7D3C98','#D7BDE2',
    '#ECF0F1','#BDC3C7','#95A5A6','#7F8C8D',
    '#2C3E50','#1A1A2E','#16213E','#0F3460',
    '#000000','#1a1a1a','#333333','#ffffff',
  ];

  return (
    <div className="flex flex-col gap-2 p-2 bg-[#161616] rounded border border-[#2a2a2a]">
      {/* Current color preview */}
      <div className="flex items-center gap-2">
        <div className="h-10 w-10 rounded border border-[#3a3a3a] shadow-inner" style={{ backgroundColor: value }} />
        <div className="flex-1">
          <div className="text-[10px] text-[#555] mb-1">HEX</div>
          <div className="flex items-center gap-1">
            <span className="text-[#555] text-[11px] font-mono">#</span>
            <input
              value={value.replace('#', '').toUpperCase()}
              onChange={(e) => {
                const v = e.target.value.replace('#', '');
                if (/^[0-9A-Fa-f]{0,6}$/.test(v)) {
                  if (v.length === 6) onChange('#' + v.toUpperCase());
                }
              }}
              className="w-full rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
              maxLength={6}
            />
          </div>
        </div>
      </div>

      {/* Preset grid */}
      <div className="grid gap-0.5" style={{ gridTemplateColumns: 'repeat(8, 1fr)' }}>
        {presets.map((hex) => (
          <button
            key={hex}
            className={`h-5 w-5 rounded-sm border transition-transform hover:scale-110 ${
              value.toLowerCase() === hex.toLowerCase()
                ? 'border-white scale-110'
                : 'border-[#1a1a1a]'
            }`}
            style={{ backgroundColor: hex }}
            onClick={() => onChange(hex)}
            title={hex}
          />
        ))}
      </div>
    </div>
  );
};

// ─── Color History Row ────────────────────────────────────────────────────────

const ColorHistoryRow: React.FC = () => {
  const { colorHistory, setForegroundColor } = useChromaStore();

  return (
    <div className="flex flex-wrap gap-1 p-2 border-b border-[#111]">
      <span className="w-full text-[9px] text-[#444] uppercase tracking-wider mb-0.5">Recent Colors</span>
      {colorHistory.map((hex, i) => (
        <button
          key={`${hex}-${i}`}
          className="h-5 w-5 rounded-sm border border-[#2a2a2a] hover:scale-110 transition-transform"
          style={{ backgroundColor: hex }}
          onClick={() => setForegroundColor(hex)}
          title={hex}
        />
      ))}
    </div>
  );
};

// ─── Main Palette Panel ───────────────────────────────────────────────────────

export const PalettePanel: React.FC = () => {
  const {
    project,
    activePalette,
    setActivePalette,
    foregroundColor,
    backgroundColor,
    setForegroundColor,
    addSwatch,
    createPalette,
  } = useChromaStore();

  const [selectedSwatchId, setSelectedSwatchId] = useState<string | null>(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [newSwatchLabel, setNewSwatchLabel] = useState('');
  const [newSwatchTag, setNewSwatchTag] = useState('');
  const [showAddSwatch, setShowAddSwatch] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showNewPalette, setShowNewPalette] = useState(false);
  const [newPaletteName, setNewPaletteName] = useState('');
  const [newPaletteChar, setNewPaletteChar] = useState('');

  if (!project) {
    return (
      <div className="flex h-full items-center justify-center text-[#333] text-xs p-4 text-center">
        Open a project to manage color palettes
      </div>
    );
  }

  const palettes = project.palettes;
  const swatches = activePalette?.swatches ?? [];
  const categories = ['all', ...new Set(swatches.map((s) => s.category))];
  const filteredSwatches =
    categoryFilter === 'all' ? swatches : swatches.filter((s) => s.category === categoryFilter);

  const selectedSwatch = swatches.find((s) => s.id === selectedSwatchId) ?? null;

  const handleAddSwatch = () => {
    if (!activePalette) return;
    addSwatch(activePalette.id, {
      hex: foregroundColor,
      label: newSwatchLabel || foregroundColor,
      tag: newSwatchTag || foregroundColor.replace('#', '').toLowerCase(),
      category: 'custom',
    });
    setNewSwatchLabel('');
    setNewSwatchTag('');
    setShowAddSwatch(false);
  };

  const handleCreatePalette = () => {
    if (!newPaletteName) return;
    createPalette(newPaletteName, newPaletteChar);
    setNewPaletteName('');
    setNewPaletteChar('');
    setShowNewPalette(false);
  };

  return (
    <div className="flex h-full flex-col text-[12px] bg-[#1e1e1e]">

      {/* ── Header: Palette selector ── */}
      <div className="flex items-center gap-1 border-b border-[#111] px-2 py-1.5 flex-shrink-0">
        <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="#888" strokeWidth={1.5}>
          <circle cx="8" cy="8" r="6" />
          <path d="M8 5v3l2 1" />
        </svg>
        <select
          value={activePalette?.id ?? ''}
          onChange={(e) => setActivePalette(e.target.value)}
          className="flex-1 rounded bg-[#161616] border border-[#2a2a2a] px-1.5 py-0.5 text-[11px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
        >
          {palettes.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name} — {p.characterName}
            </option>
          ))}
        </select>
        <button
          onClick={() => setShowNewPalette(!showNewPalette)}
          className="flex h-5 w-5 items-center justify-center rounded border border-[#2a2a2a] text-[#555] hover:border-[#2a6ac8] hover:text-[#2a6ac8]"
          title="New Palette"
        >
          <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
            <path d="M6 2v8M2 6h8" />
          </svg>
        </button>
      </div>

      {/* New palette form */}
      {showNewPalette && (
        <div className="flex flex-col gap-1.5 border-b border-[#111] bg-[#161616] p-2 flex-shrink-0">
          <input
            value={newPaletteName}
            onChange={(e) => setNewPaletteName(e.target.value)}
            placeholder="Palette name…"
            className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1 text-[11px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
          />
          <input
            value={newPaletteChar}
            onChange={(e) => setNewPaletteChar(e.target.value)}
            placeholder="Character / scene name…"
            className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1 text-[11px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
          />
          <div className="flex gap-1">
            <button
              onClick={handleCreatePalette}
              className="flex-1 rounded bg-[#2a6ac8] py-1 text-[11px] text-white hover:bg-[#3a7ad8]"
            >
              Create
            </button>
            <button
              onClick={() => setShowNewPalette(false)}
              className="flex-1 rounded border border-[#2a2a2a] py-1 text-[11px] text-[#666] hover:text-[#ccc]"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* ── Active Color Display ── */}
      <div className="flex items-center gap-2 border-b border-[#111] px-2 py-2 flex-shrink-0">
        {/* Color pair */}
        <div className="relative h-10 w-10 flex-shrink-0">
          {/* Background */}
          <div
            className="absolute bottom-0 right-0 h-7 w-7 cursor-pointer rounded-sm border-2 border-[#1e1e1e] shadow"
            style={{ backgroundColor }}
            onClick={() => setForegroundColor(backgroundColor)}
            title={`Background: ${backgroundColor}`}
          />
          {/* Foreground */}
          <div
            className="absolute left-0 top-0 z-10 h-7 w-7 cursor-pointer rounded-sm border border-[#555] shadow-md"
            style={{ backgroundColor: foregroundColor }}
            onClick={() => setShowColorPicker((v) => !v)}
            title={`Foreground: ${foregroundColor} (click to open picker)`}
          />
        </div>

        {/* Hex displays */}
        <div className="flex-1">
          <div className="flex items-center gap-1 mb-1">
            <span className="text-[9px] text-[#555] w-2">F</span>
            <div
              className="flex-1 flex items-center gap-1 rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 cursor-pointer hover:border-[#2a6ac8]"
              onClick={() => setShowColorPicker((v) => !v)}
            >
              <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: foregroundColor }} />
              <span className="text-[10px] text-[#888] font-mono">{foregroundColor.toUpperCase()}</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[9px] text-[#555] w-2">B</span>
            <div className="flex-1 flex items-center gap-1 rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5">
              <div className="h-3 w-3 rounded-sm" style={{ backgroundColor }} />
              <span className="text-[10px] text-[#555] font-mono">{backgroundColor.toUpperCase()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Color picker dropdown */}
      {showColorPicker && (
        <div className="border-b border-[#111] p-1 flex-shrink-0">
          <MiniColorPicker value={foregroundColor} onChange={(hex) => setForegroundColor(hex)} />
        </div>
      )}

      {/* ── Category filter chips ── */}
      <div className="flex gap-1 overflow-x-auto border-b border-[#111] px-2 py-1 flex-shrink-0" style={{ scrollbarWidth: 'none' }}>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`flex-shrink-0 rounded px-2 py-0.5 text-[10px] capitalize transition-colors ${
              categoryFilter === cat
                ? 'bg-[#2a6ac8] text-white'
                : 'bg-[#161616] text-[#555] hover:bg-[#2a2a2a] hover:text-[#888]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* ── Swatch Grid ── */}
      <div className="flex-1 overflow-y-auto p-2" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>
        {filteredSwatches.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <div className="h-8 w-8 rounded-full bg-[#161616] flex items-center justify-center">
              <svg viewBox="0 0 16 16" width={14} height={14} fill="none" stroke="#444" strokeWidth={1.5}>
                <circle cx="8" cy="8" r="5" />
                <path d="M8 5v3l2 1" />
              </svg>
            </div>
            <p className="text-[11px] text-[#444]">No swatches in this category</p>
          </div>
        ) : (
          <div className="flex flex-wrap gap-1.5">
            {filteredSwatches.map((swatch) => (
              <SwatchItem
                key={swatch.id}
                swatch={swatch}
                paletteId={activePalette!.id}
                isSelected={selectedSwatchId === swatch.id}
                onClick={() => setSelectedSwatchId(swatch.id === selectedSwatchId ? null : swatch.id)}
              />
            ))}
          </div>
        )}
      </div>

      {/* ── Selected Swatch Detail ── */}
      {selectedSwatch && (
        <div className="border-t border-[#111] bg-[#161616] p-2 flex-shrink-0">
          <div className="flex items-center gap-2">
            <div
              className="h-8 w-8 rounded-sm border border-[#3a3a3a] flex-shrink-0"
              style={{ backgroundColor: selectedSwatch.hex }}
            />
            <div className="flex-1 min-w-0">
              <div className="text-[11px] text-[#ccc] font-medium truncate">{selectedSwatch.label}</div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-[#888] font-mono">{selectedSwatch.hex}</span>
                <span className="text-[10px] text-[#555] bg-[#1e1e1e] px-1 rounded">#{selectedSwatch.tag}</span>
              </div>
            </div>
            <button
              onClick={() => setForegroundColor(selectedSwatch.hex)}
              className="text-[#555] hover:text-[#2a6ac8] flex-shrink-0"
              title="Set as active color"
            >
              <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5}>
                <path d="M2 14l1-1h3l8-8-3-3-8 8v3h-1z" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* ── Color History ── */}
      <ColorHistoryRow />

      {/* ── Add Swatch Button ── */}
      <div className="flex-shrink-0 border-t border-[#111] p-1.5">
        {showAddSwatch ? (
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-1">
              <div className="h-5 w-5 rounded-sm border border-[#3a3a3a] flex-shrink-0" style={{ backgroundColor: foregroundColor }} />
              <input
                autoFocus
                value={newSwatchLabel}
                onChange={(e) => setNewSwatchLabel(e.target.value)}
                placeholder="Label (e.g. Veste Héros)"
                className="flex-1 rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 text-[11px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
              />
            </div>
            <input
              value={newSwatchTag}
              onChange={(e) => setNewSwatchTag(e.target.value.replace(/\s/g, '_').toLowerCase())}
              placeholder="Tag (e.g. jacket_main)"
              className="w-full rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 text-[11px] text-[#ccc] outline-none focus:border-[#2a6ac8] font-mono"
            />
            <div className="flex gap-1">
              <button
                onClick={handleAddSwatch}
                className="flex-1 rounded bg-[#2a6ac8] py-1 text-[10px] text-white hover:bg-[#3a7ad8]"
              >
                Add Swatch
              </button>
              <button
                onClick={() => setShowAddSwatch(false)}
                className="rounded border border-[#2a2a2a] px-2 py-1 text-[10px] text-[#666] hover:text-[#ccc]"
              >
                ✕
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowAddSwatch(true)}
            className="flex w-full items-center justify-center gap-1 rounded border border-dashed border-[#2a2a2a] py-1.5 text-[11px] text-[#444] hover:border-[#2a6ac8] hover:text-[#2a6ac8] transition-colors"
            disabled={!activePalette}
          >
            <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
              <path d="M6 2v8M2 6h8" />
            </svg>
            Add Swatch from Active Color
          </button>
        )}
      </div>
    </div>
  );
};
