/**
 * ChromaFlow — Welcome / Project Setup Screen
 */

import React, { useState } from 'react';
import { useChromaStore } from '../store/chromaStore';

const RECENT_PROJECTS = [
  { name: 'Kaito — Episode 3', path: '/projects/kaito_ep3.chroma', frames: 24, date: '2025-01-14', colorized: 8 },
  { name: 'Sakura BG — Scene 7', path: '/projects/sakura_bg_s7.chroma', frames: 48, date: '2025-01-12', colorized: 48 },
  { name: 'Robot Walk Cycle', path: '/projects/robot_walk.chroma', frames: 12, date: '2025-01-10', colorized: 12 },
];

const TEMPLATES = [
  { name: 'Anime Action — 1920×1080 @ 24fps', desc: 'Optimized for action sequences' },
  { name: 'TV Animation — 1280×720 @ 12fps', desc: 'Standard TV animation settings' },
  { name: 'Short Film — 4K @ 24fps', desc: 'High-resolution cinematic format' },
  { name: 'Web Clip — 1080×1080 @ 30fps', desc: 'Square format for social media' },
];

export const WelcomeScreen: React.FC = () => {
  const { createProject, loadDemoProject, setShowWelcome } = useChromaStore();
  const [showNewProject, setShowNewProject] = useState(false);
  const [projectName, setProjectName] = useState('My Animation');
  const [width, setWidth] = useState(1920);
  const [height, setHeight] = useState(1080);
  const [fps, setFps] = useState(24);

  const handleCreate = () => {
    if (!projectName.trim()) return;
    createProject(projectName, width, height, fps);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0d0d0d]">
      {/* Background pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: 'repeating-linear-gradient(45deg, #2a6ac8 0, #2a6ac8 1px, transparent 0, transparent 50%)',
          backgroundSize: '20px 20px',
        }}
      />

      <div className="relative w-[800px] max-h-[90vh] overflow-hidden flex flex-col">

        {/* Logo + Title */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            {/* Logo */}
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-[#1a3a6a] to-[#533483] shadow-2xl border border-[#2a6ac8] border-opacity-30">
              <svg viewBox="0 0 40 40" className="h-10 w-10" fill="none">
                <circle cx="20" cy="20" r="18" fill="#0d1f35" />
                <path d="M14 20 Q20 10 26 20 Q20 30 14 20Z" fill="#FF5733" opacity="0.9" />
                <path d="M20 14 Q30 20 20 26 Q10 20 20 14Z" fill="#2E8B57" opacity="0.8" />
                <path d="M20 14 Q26 20 20 26Z" fill="#533483" opacity="0.5" />
                <circle cx="20" cy="20" r="4" fill="white" opacity="0.9" />
              </svg>
            </div>
            <div className="text-left">
              <h1 className="text-4xl font-black tracking-tight text-white">ChromaFlow</h1>
              <p className="text-[#5fb8ff] text-sm font-medium tracking-widest uppercase">2D Animation Auto-Colorization</p>
            </div>
          </div>
          <div className="flex items-center justify-center gap-3 text-[12px] text-[#333]">
            {['100% Offline', 'Privacy-First', 'SAM 2 + RAFT', 'PyTorch Local'].map((tag) => (
              <span key={tag} className="rounded-full border border-[#2a2a2a] px-3 py-0.5">{tag}</span>
            ))}
          </div>
        </div>

        {!showNewProject ? (
          <div className="grid grid-cols-2 gap-6">

            {/* Left: Actions */}
            <div className="space-y-3">
              <h2 className="text-[12px] font-semibold text-[#555] uppercase tracking-wider">Start</h2>

              <button
                onClick={() => setShowNewProject(true)}
                className="w-full flex items-center gap-3 rounded-xl border border-[#2a6ac8] border-opacity-40 bg-[#1a3a6a] bg-opacity-30 p-4 text-left transition-all hover:bg-opacity-50 hover:border-opacity-60 group"
              >
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-[#2a6ac8] bg-opacity-20 group-hover:bg-opacity-30 transition-colors">
                  <svg viewBox="0 0 20 20" width={18} height={18} fill="none" stroke="#7ab4ff" strokeWidth={1.5}>
                    <path d="M10 4v12M4 10h12" />
                  </svg>
                </div>
                <div>
                  <div className="text-[13px] font-semibold text-[#ccc]">New Project</div>
                  <div className="text-[10px] text-[#555]">Create a blank animation project</div>
                </div>
              </button>

              <button
                onClick={loadDemoProject}
                className="w-full flex items-center gap-3 rounded-xl border border-[#533483] border-opacity-40 bg-[#1a1530] bg-opacity-40 p-4 text-left transition-all hover:bg-opacity-60 group"
              >
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-[#533483] bg-opacity-20 group-hover:bg-opacity-30 transition-colors">
                  <svg viewBox="0 0 20 20" width={18} height={18} fill="none" stroke="#A5D6A7" strokeWidth={1.5}>
                    <path d="M8 3L3 8l5 5" />
                    <path d="M17 12V8a5 5 0 0 0-5-5H5" />
                    <path d="M12 17l5-5-5-5" />
                    <path d="M3 12v4a1 1 0 0 0 1 1h4" />
                  </svg>
                </div>
                <div>
                  <div className="text-[13px] font-semibold text-[#ccc]">Load Demo Project</div>
                  <div className="text-[10px] text-[#555]">24-frame anime walk cycle — Kaito character</div>
                </div>
              </button>

              <button
                onClick={() => setShowWelcome(false)}
                className="w-full flex items-center gap-3 rounded-xl border border-[#2a2a2a] p-4 text-left transition-all hover:bg-[#1e1e1e] group"
              >
                <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-[#1e1e1e] group-hover:bg-[#2a2a2a] transition-colors">
                  <svg viewBox="0 0 20 20" width={18} height={18} fill="none" stroke="#666" strokeWidth={1.5}>
                    <path d="M3 6h14M3 10h14M3 14h14" />
                  </svg>
                </div>
                <div>
                  <div className="text-[13px] font-semibold text-[#666]">Open Project…</div>
                  <div className="text-[10px] text-[#444]">Browse for a .chroma project file</div>
                </div>
              </button>

              {/* Templates */}
              <div className="pt-2">
                <h2 className="text-[12px] font-semibold text-[#555] uppercase tracking-wider mb-2">Templates</h2>
                <div className="space-y-1">
                  {TEMPLATES.map((t) => (
                    <button
                      key={t.name}
                      onClick={loadDemoProject}
                      className="w-full flex items-center gap-2 rounded-lg border border-[#1e1e1e] bg-[#161616] px-3 py-2 text-left transition-all hover:border-[#2a2a2a] hover:bg-[#1e1e1e]"
                    >
                      <div className="h-4 w-4 rounded-sm bg-gradient-to-br from-[#2a6ac8] to-[#533483] flex-shrink-0" />
                      <div>
                        <div className="text-[11px] text-[#888]">{t.name}</div>
                        <div className="text-[9px] text-[#444]">{t.desc}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Recent projects */}
            <div>
              <h2 className="text-[12px] font-semibold text-[#555] uppercase tracking-wider mb-3">Recent</h2>
              <div className="space-y-2">
                {RECENT_PROJECTS.map((proj) => (
                  <button
                    key={proj.path}
                    onClick={loadDemoProject}
                    className="w-full flex items-start gap-3 rounded-xl border border-[#1e1e1e] bg-[#161616] p-3 text-left transition-all hover:border-[#2a2a2a] hover:bg-[#1e1e1e]"
                  >
                    {/* Thumbnail preview */}
                    <div
                      className="flex-shrink-0 rounded border border-[#2a2a2a]"
                      style={{ width: 48, height: 32, background: 'linear-gradient(135deg, #1A1A2E, #FF5733 60%, #2E8B57)' }}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-[12px] font-medium text-[#ccc] truncate">{proj.name}</div>
                      <div className="text-[10px] text-[#444] mt-0.5">{proj.date} — {proj.frames} frames</div>
                      <div className="flex items-center gap-1.5 mt-1">
                        <div className="h-1 flex-1 rounded-full bg-[#1a1a1a] overflow-hidden">
                          <div
                            className="h-full rounded-full bg-[#2ECC71]"
                            style={{ width: `${(proj.colorized / proj.frames) * 100}%` }}
                          />
                        </div>
                        <span className="text-[9px] text-[#555] flex-shrink-0">{proj.colorized}/{proj.frames}</span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {/* What's new */}
              <div className="mt-4 rounded-xl border border-[#2a2a2a] bg-[#161616] p-3">
                <h3 className="text-[11px] font-semibold text-[#666] uppercase tracking-wider mb-2">What's New in v1.0</h3>
                <div className="space-y-1 text-[10px] text-[#444]">
                  {[
                    '🔬 SAM 2.1 — improved small region detection',
                    '⚡ RAFT optical flow — 2× faster propagation',
                    '🎨 Per-character palette enforcement',
                    '🧠 Instant correction learning (no retraining)',
                    '📦 Multi-layer PSD export with alpha',
                  ].map((item) => (
                    <div key={item}>{item}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          // New Project form
          <div className="w-full max-w-md mx-auto bg-[#161616] rounded-2xl border border-[#2a2a2a] p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-[14px] font-semibold text-[#ccc]">New Project</h2>
              <button onClick={() => setShowNewProject(false)} className="text-[#444] hover:text-[#888]">
                <svg viewBox="0 0 16 16" width={14} height={14} fill="none" stroke="currentColor" strokeWidth={1.5}>
                  <path d="M4 4l8 8M12 4l-8 8" />
                </svg>
              </button>
            </div>

            <div>
              <label className="text-[10px] text-[#555] block mb-1">Project Name</label>
              <input
                autoFocus
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="w-full rounded-lg border border-[#2a2a2a] bg-[#111] px-3 py-2 text-[13px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
                placeholder="My Animation Project"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-[#555] block mb-1">Width (px)</label>
                <input
                  type="number"
                  value={width}
                  onChange={(e) => setWidth(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#2a2a2a] bg-[#111] px-3 py-2 text-[13px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#555] block mb-1">Height (px)</label>
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#2a2a2a] bg-[#111] px-3 py-2 text-[13px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-[#555] block mb-1">Frame Rate</label>
                <select
                  value={fps}
                  onChange={(e) => setFps(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#2a2a2a] bg-[#111] px-3 py-2 text-[13px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
                >
                  {[8, 12, 24, 25, 30, 60].map((f) => (
                    <option key={f} value={f}>{f} fps</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-[#555] block mb-1">Preset</label>
                <select
                  onChange={(e) => {
                    const [w, h] = e.target.value.split('x').map(Number);
                    setWidth(w); setHeight(h);
                  }}
                  className="w-full rounded-lg border border-[#2a2a2a] bg-[#111] px-3 py-2 text-[13px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
                >
                  <option value="1920x1080">1920×1080 FHD</option>
                  <option value="3840x2160">3840×2160 4K</option>
                  <option value="1280x720">1280×720 HD</option>
                  <option value="1080x1080">1080×1080 Square</option>
                </select>
              </div>
            </div>

            {/* Preset quick-select */}
            <div className="grid grid-cols-2 gap-2">
              {TEMPLATES.slice(0, 4).map((t) => (
                <button
                  key={t.name}
                  onClick={loadDemoProject}
                  className="rounded-lg border border-[#2a2a2a] bg-[#111] p-2 text-left text-[9px] text-[#444] hover:border-[#2a6ac8] hover:text-[#7ab4ff] transition-colors"
                >
                  {t.name}
                </button>
              ))}
            </div>

            <button
              onClick={handleCreate}
              disabled={!projectName.trim()}
              className="w-full rounded-lg bg-[#2a6ac8] py-3 text-[13px] font-bold text-white hover:bg-[#3a7ad8] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Create Project
            </button>
          </div>
        )}

        {/* Version footer */}
        <div className="text-center mt-6 text-[10px] text-[#333]">
          ChromaFlow v1.0.0 — Python 3.11 + PyTorch 2.4 + SAM 2 + RAFT — 100% offline, 0% telemetry
        </div>
      </div>
    </div>
  );
};
