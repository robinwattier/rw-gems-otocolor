/**
 * ChromaFlow — Tool Properties Panel
 * Context-sensitive tool settings (brush size, opacity, flow, hardness, etc.)
 */

import React from 'react';
import { useChromaStore } from '../store/chromaStore';

const Slider: React.FC<{
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (v: number) => void;
  color?: string;
}> = ({ label, value, min, max, step = 1, unit = '', onChange, color = '#2a6ac8' }) => (
  <div className="space-y-0.5">
    <div className="flex items-center justify-between">
      <span className="text-[10px] text-[#555]">{label}</span>
      <span className="text-[10px] text-[#888] font-mono">{value}{unit}</span>
    </div>
    <div className="relative h-3 flex items-center">
      <div className="h-1 w-full rounded-full bg-[#1a1a1a] overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${((value - min) / (max - min)) * 100}%`, backgroundColor: color }}
        />
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="absolute inset-0 w-full opacity-0 cursor-pointer"
      />
    </div>
  </div>
);

const toolDescriptions: Record<string, { name: string; desc: string; color: string }> = {
  select: { name: 'Select / Move', desc: 'Click to select regions. Drag to move.', color: '#7ab4ff' },
  brush: { name: 'Brush', desc: 'Paint with current foreground color.', color: '#FF8C69' },
  fill: { name: 'Paint Bucket', desc: 'Fill closed regions with the active color.', color: '#F39C12' },
  eyedropper: { name: 'Eyedropper', desc: 'Sample any color from the canvas.', color: '#E91E63' },
  eraser: { name: 'Eraser', desc: 'Erase painted color areas.', color: '#95A5A6' },
  pan: { name: 'Pan / Hand', desc: 'Click and drag to pan the canvas.', color: '#7ab4ff' },
  zoom: { name: 'Zoom', desc: 'Click to zoom in. Alt+Click to zoom out.', color: '#7ab4ff' },
  lasso: { name: 'Lasso Select', desc: 'Draw a freehand selection.', color: '#7ab4ff' },
  smartFill: { name: 'Smart Fill (SAM 2)', desc: 'AI-powered semantic region detection and fill.', color: '#5fb8ff' },
  semanticTag: { name: 'Semantic Tag', desc: 'Tag a region with a palette label for AI learning.', color: '#A5D6A7' },
};

export const PropertiesPanel: React.FC = () => {
  const {
    activeTool,
    brushSize,
    setBrushSize,
    brushOpacity,
    setBrushOpacity,
    foregroundColor,
    canvas,
    setZoom,
    setRotation,
    toggleGrid,
    toggleOnionSkin,
  } = useChromaStore();

  const toolInfo = toolDescriptions[activeTool] ?? toolDescriptions.select;

  return (
    <div className="flex h-full flex-col bg-[#1e1e1e] text-[12px]">
      {/* Active tool header */}
      <div className="border-b border-[#111] px-3 py-2 flex-shrink-0">
        <div className="flex items-center gap-2 mb-0.5">
          <div className="h-2 w-2 rounded-full" style={{ backgroundColor: toolInfo.color }} />
          <span className="text-[12px] font-semibold text-[#ccc]">{toolInfo.name}</span>
        </div>
        <p className="text-[10px] text-[#444]">{toolInfo.desc}</p>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>

        {/* ── Brush Settings ── */}
        {(activeTool === 'brush' || activeTool === 'eraser') && (
          <div className="space-y-3">
            <h4 className="text-[10px] font-semibold text-[#555] uppercase tracking-wider">Brush</h4>
            <Slider label="Size" value={brushSize} min={1} max={200} unit="px" onChange={setBrushSize} />
            <Slider label="Opacity" value={brushOpacity} min={0} max={100} unit="%" onChange={setBrushOpacity} />
            <Slider label="Flow" value={80} min={0} max={100} unit="%" onChange={() => {}} color="#9B59B6" />
            <Slider label="Hardness" value={90} min={0} max={100} unit="%" onChange={() => {}} color="#E74C3C" />
            <Slider label="Spacing" value={5} min={1} max={200} unit="%" onChange={() => {}} color="#F39C12" />

            <div className="space-y-1">
              <span className="text-[10px] text-[#555]">Shape</span>
              <div className="flex gap-1.5">
                {['round', 'square', 'flat', 'bristle'].map((shape) => (
                  <button
                    key={shape}
                    className={`rounded border px-2 py-1 text-[9px] capitalize transition-colors ${
                      shape === 'round'
                        ? 'border-[#2a6ac8] bg-[#1a3a6a] text-[#7ab4ff]'
                        : 'border-[#2a2a2a] text-[#444] hover:border-[#3a3a3a]'
                    }`}
                  >
                    {shape}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#555]">Stabilizer</span>
              <div className="flex items-center gap-1.5">
                <div className="h-3.5 w-6 rounded-full bg-[#2a6ac8] relative cursor-pointer">
                  <div className="absolute right-0.5 top-0.5 h-2.5 w-2.5 rounded-full bg-white shadow" />
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  defaultValue={60}
                  className="w-16 accent-[#2a6ac8]"
                  style={{ height: 3 }}
                />
              </div>
            </div>
          </div>
        )}

        {/* ── Fill Settings ── */}
        {activeTool === 'fill' && (
          <div className="space-y-3">
            <h4 className="text-[10px] font-semibold text-[#555] uppercase tracking-wider">Fill</h4>
            <Slider label="Tolerance" value={32} min={0} max={255} onChange={() => {}} color="#F39C12" />
            <Slider label="Feather" value={0} min={0} max={50} unit="px" onChange={() => {}} />
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#555]">Fill Mode</span>
              <select className="rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 text-[10px] text-[#888]">
                <option>Contiguous</option>
                <option>All Matching Colors</option>
                <option>Selection Only</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#555]">Anti-alias</span>
              <div className="h-3.5 w-6 rounded-full bg-[#2a6ac8] relative cursor-pointer">
                <div className="absolute right-0.5 top-0.5 h-2.5 w-2.5 rounded-full bg-white shadow" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#555]">Close Gaps</span>
              <div className="h-3.5 w-6 rounded-full bg-[#2a6ac8] relative cursor-pointer">
                <div className="absolute right-0.5 top-0.5 h-2.5 w-2.5 rounded-full bg-white shadow" />
              </div>
            </div>
          </div>
        )}

        {/* ── Smart Fill (AI) Settings ── */}
        {activeTool === 'smartFill' && (
          <div className="space-y-3">
            <h4 className="text-[10px] font-semibold text-[#5fb8ff] uppercase tracking-wider">SAM 2 Smart Fill</h4>
            <Slider label="Confidence Threshold" value={75} min={0} max={100} unit="%" onChange={() => {}} color="#5fb8ff" />
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#555]">Segmentation Mode</span>
              <select className="rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 text-[10px] text-[#888]">
                <option>Automatic</option>
                <option>Point Prompt</option>
                <option>Box Prompt</option>
                <option>Semantic</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#555]">Multi-mask</span>
              <div className="h-3.5 w-6 rounded-full bg-[#2a6ac8] relative cursor-pointer">
                <div className="absolute right-0.5 top-0.5 h-2.5 w-2.5 rounded-full bg-white shadow" />
              </div>
            </div>
            <div className="rounded border border-[#5fb8ff] border-opacity-20 bg-[#0d1f35] p-2 text-[10px] text-[#555]">
              Click on any region to auto-detect its boundary using SAM 2. The model understands complex poses and occlusions.
            </div>
          </div>
        )}

        {/* ── Semantic Tag Settings ── */}
        {activeTool === 'semanticTag' && (
          <div className="space-y-3">
            <h4 className="text-[10px] font-semibold text-[#A5D6A7] uppercase tracking-wider">Semantic Tagging</h4>
            <div className="space-y-1">
              <span className="text-[10px] text-[#555]">Tag Name</span>
              <input
                defaultValue="jacket_main"
                className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-[#555]">Label (Human-readable)</span>
              <input
                defaultValue="Veste Héros"
                className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1 text-[11px] text-[#ccc] outline-none focus:border-[#2a6ac8]"
              />
            </div>
            <div className="rounded border border-[#A5D6A7] border-opacity-20 bg-[#0d1f15] p-2 text-[10px] text-[#555]">
              Click on a region to assign a palette tag. This teaches the AI which body part corresponds to which color rule.
            </div>
          </div>
        )}

        {/* ── Canvas / View ── */}
        <div className="space-y-3 border-t border-[#111] pt-3">
          <h4 className="text-[10px] font-semibold text-[#555] uppercase tracking-wider">Canvas View</h4>
          <Slider label="Zoom" value={Math.round(canvas.zoom * 100)} min={5} max={3200} unit="%" onChange={(v) => setZoom(v / 100)} />
          <Slider label="Rotation" value={canvas.rotation} min={-180} max={180} unit="°" onChange={setRotation} />
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-[#555]">Grid</span>
            <button
              onClick={toggleGrid}
              className={`h-3.5 w-6 rounded-full relative cursor-pointer transition-colors ${canvas.showGrid ? 'bg-[#2a6ac8]' : 'bg-[#2a2a2a]'}`}
            >
              <div className={`absolute top-0.5 h-2.5 w-2.5 rounded-full bg-white shadow transition-transform ${canvas.showGrid ? 'right-0.5' : 'left-0.5'}`} />
            </button>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-[#555]">Onion Skin</span>
            <button
              onClick={toggleOnionSkin}
              className={`h-3.5 w-6 rounded-full relative cursor-pointer transition-colors ${canvas.showOnionSkin ? 'bg-[#2a6ac8]' : 'bg-[#2a2a2a]'}`}
            >
              <div className={`absolute top-0.5 h-2.5 w-2.5 rounded-full bg-white shadow transition-transform ${canvas.showOnionSkin ? 'right-0.5' : 'left-0.5'}`} />
            </button>
          </div>
          {canvas.showOnionSkin && (
            <Slider label="Onion Frames" value={canvas.onionSkinFrames} min={1} max={5} onChange={() => {}} />
          )}
        </div>

        {/* ── Color Transform ── */}
        <div className="space-y-3 border-t border-[#111] pt-3">
          <h4 className="text-[10px] font-semibold text-[#555] uppercase tracking-wider">Active Color</h4>
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded border border-[#3a3a3a]" style={{ backgroundColor: foregroundColor }} />
            <div className="flex-1 space-y-0.5">
              <div className="text-[11px] text-[#ccc] font-mono">{foregroundColor.toUpperCase()}</div>
              <div className="flex gap-1">
                {['H', 'S', 'V'].map((ch) => (
                  <div key={ch} className="flex-1 text-center rounded bg-[#161616] py-0.5 text-[9px] text-[#444]">{ch}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
