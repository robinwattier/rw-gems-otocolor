/**
 * ChromaFlow — Tool Options Bar
 * Context-sensitive tool options shown at the top of the canvas
 */

import React from 'react';
import { useChromaStore } from '../store/chromaStore';

export const ToolOptionsBar: React.FC = () => {
  const {
    activeTool,
    brushSize,
    setBrushSize,
    brushOpacity,
    setBrushOpacity,
    canvas,
    setZoom,
    toggleGrid,
    toggleOnionSkin,
    project,
    currentFrameIndex,
    markAsKeyframe,
    currentPhase,
    startPropagation,
    setShowExportDialog,
    aiProgress,
    learnFromCorrection,
  } = useChromaStore();

  const currentFrame = project?.frames[currentFrameIndex];

  return (
    <div className="flex h-8 flex-shrink-0 items-center gap-2 border-b border-[#111] bg-[#1a1a1a] px-3 select-none overflow-x-auto" style={{ scrollbarWidth: 'none' }}>

      {/* Tool-specific options */}
      {(activeTool === 'brush' || activeTool === 'eraser') && (
        <>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-[#444]">Size:</span>
            <input
              type="range"
              min={1}
              max={200}
              value={brushSize}
              onChange={(e) => setBrushSize(Number(e.target.value))}
              className="w-20 accent-[#2a6ac8]"
              style={{ height: 3 }}
            />
            <span className="text-[10px] text-[#666] font-mono w-7">{brushSize}px</span>
          </div>

          <div className="h-4 w-px bg-[#2a2a2a]" />

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-[#444]">Opacity:</span>
            <input
              type="range"
              min={0}
              max={100}
              value={brushOpacity}
              onChange={(e) => setBrushOpacity(Number(e.target.value))}
              className="w-20 accent-[#2a6ac8]"
              style={{ height: 3 }}
            />
            <span className="text-[10px] text-[#666] font-mono w-7">{brushOpacity}%</span>
          </div>

          <div className="h-4 w-px bg-[#2a2a2a]" />

          <div className="flex items-center gap-1">
            {['Round', 'Square', 'Flat'].map((shape) => (
              <button
                key={shape}
                className={`rounded px-2 py-0.5 text-[9px] transition-colors ${
                  shape === 'Round'
                    ? 'bg-[#2a6ac8] bg-opacity-30 text-[#7ab4ff]'
                    : 'text-[#444] hover:text-[#888]'
                }`}
              >
                {shape}
              </button>
            ))}
          </div>
        </>
      )}

      {activeTool === 'fill' && (
        <>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-[#444]">Tolerance:</span>
            <input type="range" min={0} max={255} defaultValue={32} className="w-20 accent-[#F39C12]" style={{ height: 3 }} />
            <span className="text-[10px] text-[#666] font-mono">32</span>
          </div>
          <div className="h-4 w-px bg-[#2a2a2a]" />
          <button className="rounded border border-[#2a6ac8] border-opacity-40 px-2 py-0.5 text-[9px] text-[#7ab4ff] bg-[#1a3a6a] bg-opacity-20">
            Close Gaps
          </button>
          <button className="rounded border border-[#2a2a2a] px-2 py-0.5 text-[9px] text-[#444] hover:text-[#888]">
            Contiguous
          </button>
        </>
      )}

      {activeTool === 'smartFill' && (
        <>
          <div className="flex items-center gap-1 text-[#5fb8ff]">
            <div className="h-1.5 w-1.5 rounded-full bg-[#5fb8ff] animate-pulse" />
            <span className="text-[10px] font-medium">SAM 2 Active</span>
          </div>
          <div className="h-4 w-px bg-[#2a2a2a]" />
          <span className="text-[10px] text-[#444]">Mode:</span>
          <select className="rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 text-[10px] text-[#888] outline-none">
            <option>Point Prompt</option>
            <option>Box Prompt</option>
            <option>Automatic</option>
          </select>
          <div className="h-4 w-px bg-[#2a2a2a]" />
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-[#444]">Confidence:</span>
            <input type="range" min={0} max={100} defaultValue={75} className="w-16 accent-[#5fb8ff]" style={{ height: 3 }} />
            <span className="text-[10px] text-[#5fb8ff] font-mono">75%</span>
          </div>
        </>
      )}

      {activeTool === 'semanticTag' && (
        <>
          <span className="text-[10px] text-[#A5D6A7]">Tag Mode — Click to label a region</span>
          <div className="h-4 w-px bg-[#2a2a2a]" />
          <input
            placeholder="tag_name…"
            className="w-28 rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-0.5 text-[10px] text-[#ccc] font-mono outline-none focus:border-[#A5D6A7]"
          />
        </>
      )}

      {activeTool === 'select' && (
        <span className="text-[10px] text-[#444]">Click to select — Drag to move selection</span>
      )}

      {activeTool === 'pan' && (
        <span className="text-[10px] text-[#444]">Click and drag to pan canvas — Scroll wheel to zoom</span>
      )}

      {activeTool === 'zoom' && (
        <span className="text-[10px] text-[#444]">Click to zoom in — Alt+Click to zoom out</span>
      )}

      {/* Spacer */}
      <div className="flex-1" />

      {/* Global quick actions */}
      <div className="flex items-center gap-1.5 flex-shrink-0">

        {/* View toggles */}
        <button
          onClick={toggleGrid}
          className={`flex items-center gap-1 rounded px-1.5 py-0.5 text-[9px] transition-colors ${
            canvas.showGrid ? 'bg-[#1a3a6a] text-[#7ab4ff]' : 'text-[#444] hover:text-[#888]'
          }`}
          title="Toggle Grid (G)"
        >
          <svg viewBox="0 0 12 12" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1}>
            <path d="M0 4h12M0 8h12M4 0v12M8 0v12" />
          </svg>
          Grid
        </button>

        <button
          onClick={toggleOnionSkin}
          className={`flex items-center gap-1 rounded px-1.5 py-0.5 text-[9px] transition-colors ${
            canvas.showOnionSkin ? 'bg-[#1a3a6a] text-[#7ab4ff]' : 'text-[#444] hover:text-[#888]'
          }`}
          title="Toggle Onion Skin (O)"
        >
          Onion
        </button>

        <div className="h-4 w-px bg-[#2a2a2a]" />

        {/* Zoom display */}
        <div className="flex items-center gap-1">
          <button onClick={() => setZoom(canvas.zoom * 0.8)} className="text-[#444] hover:text-[#888] w-3 text-center">−</button>
          <span className="text-[10px] text-[#555] font-mono w-10 text-center">{Math.round(canvas.zoom * 100)}%</span>
          <button onClick={() => setZoom(canvas.zoom * 1.25)} className="text-[#444] hover:text-[#888] w-3 text-center">+</button>
        </div>

        <div className="h-4 w-px bg-[#2a2a2a]" />

        {/* Keyframe toggle */}
        {project && (
          <button
            onClick={() => markAsKeyframe(currentFrameIndex)}
            className={`flex items-center gap-1 rounded px-2 py-0.5 text-[9px] transition-colors ${
              currentFrame?.isKeyframe
                ? 'bg-[#3a2a00] text-[#FFD700]'
                : 'text-[#444] hover:text-[#FFD700]'
            }`}
            title="Toggle Keyframe (K)"
          >
            ★ {currentFrame?.isKeyframe ? 'Keyframe' : 'Set Key'}
          </button>
        )}

        <div className="h-4 w-px bg-[#2a2a2a]" />

        {/* Phase quick actions */}
        {currentPhase === 'propagation' && !aiProgress.isRunning && (
          <button
            onClick={startPropagation}
            className="flex items-center gap-1 rounded bg-[#2a6ac8] px-3 py-0.5 text-[9px] font-bold text-white hover:bg-[#3a7ad8] transition-colors"
          >
            ⚡ Propagate
          </button>
        )}

        {currentPhase === 'refinement' && (
          <button
            onClick={() => learnFromCorrection(currentFrameIndex)}
            disabled={aiProgress.isRunning}
            className="flex items-center gap-1 rounded bg-[#533483] px-3 py-0.5 text-[9px] font-bold text-white hover:bg-[#6342a0] disabled:opacity-50 transition-colors"
          >
            🧠 Learn
          </button>
        )}

        <button
          onClick={() => setShowExportDialog(true)}
          disabled={!project}
          className="flex items-center gap-1 rounded border border-[#2a2a2a] px-2 py-0.5 text-[9px] text-[#555] hover:border-[#2a6ac8] hover:text-[#7ab4ff] disabled:opacity-40 transition-colors"
          title="Export (Ctrl+E)"
        >
          Export
        </button>
      </div>
    </div>
  );
};
