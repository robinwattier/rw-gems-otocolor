/**
 * ChromaFlow — Professional Timeline Panel
 * Frame scrubber, keyframe markers, onion skin controls, playback
 */

import React, { useRef, useState, useEffect } from 'react';
import { useChromaStore } from '../store/chromaStore';

const PlayIcon = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor">
    <path d="M4 2l10 6-10 6V2z" />
  </svg>
);
const PauseIcon = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor">
    <rect x="3" y="2" width="4" height="12" />
    <rect x="9" y="2" width="4" height="12" />
  </svg>
);
const StopIcon = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor">
    <rect x="3" y="3" width="10" height="10" />
  </svg>
);
const SkipBackIcon = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor">
    <rect x="2" y="2" width="2" height="12" />
    <path d="M13 2L5 8l8 6V2z" />
  </svg>
);
const SkipForwardIcon = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor">
    <rect x="12" y="2" width="2" height="12" />
    <path d="M3 2l8 6-8 6V2z" />
  </svg>
);
const PrevFrameIcon = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor">
    <path d="M11 2L5 8l6 6V2z" />
    <rect x="3" y="2" width="2" height="12" />
  </svg>
);
const NextFrameIcon = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor">
    <path d="M5 2l6 6-6 6V2z" />
    <rect x="11" y="2" width="2" height="12" />
  </svg>
);

interface FrameCellProps {
  frameIndex: number;
  isCurrentFrame: boolean;
  isKeyframe: boolean;
  isColorized: boolean;
  hasCorrections: boolean;
  confidence: number;
  onClick: () => void;
  onDoubleClick: () => void;
  onContextMenu: (e: React.MouseEvent) => void;
}

const FrameCell: React.FC<FrameCellProps> = ({
  frameIndex,
  isCurrentFrame,
  isKeyframe,
  isColorized,
  hasCorrections,
  confidence,
  onClick,
  onDoubleClick,
  onContextMenu,
}) => {
  const confColor = confidence > 0.9 ? '#2ECC71' : confidence > 0.75 ? '#F39C12' : '#E74C3C';

  return (
    <div
      className={`relative flex-shrink-0 flex flex-col items-center cursor-pointer group transition-colors ${
        isCurrentFrame
          ? 'bg-[#2a6ac8]'
          : isKeyframe
          ? 'bg-[#3a2a1a] hover:bg-[#4a3a2a]'
          : 'bg-[#1e1e1e] hover:bg-[#252525]'
      }`}
      style={{ width: 36, borderRight: '1px solid #111' }}
      onClick={onClick}
      onDoubleClick={onDoubleClick}
      onContextMenu={onContextMenu}
    >
      {/* Frame number */}
      <div className={`text-[9px] font-mono pt-0.5 leading-none ${isCurrentFrame ? 'text-white' : 'text-[#444]'}`}>
        {(frameIndex + 1).toString().padStart(2, '0')}
      </div>

      {/* Frame thumbnail area */}
      <div
        className={`mx-0.5 my-0.5 rounded-sm ${
          isColorized ? 'border border-[#333]' : 'border border-dashed border-[#2a2a2a]'
        }`}
        style={{ width: 28, height: 20, backgroundColor: isColorized ? '#1a1a2e' : '#1a1a1a' }}
      >
        {isColorized && (
          <div className="w-full h-full rounded-sm" style={{
            background: `linear-gradient(135deg, #1A1A2E, #FF5733 60%, #2E8B57)`,
            opacity: 0.7,
          }} />
        )}
      </div>

      {/* Bottom indicators */}
      <div className="flex items-center justify-center gap-0.5 pb-0.5">
        {/* Keyframe diamond */}
        {isKeyframe && (
          <div
            className="h-2 w-2 rotate-45"
            style={{ backgroundColor: '#FFD700', marginBottom: 0 }}
            title="Keyframe"
          />
        )}
        {/* Color confidence bar */}
        {isColorized && confidence > 0 && (
          <div
            className="h-0.5 rounded-full"
            style={{
              width: 18,
              backgroundColor: confColor,
              opacity: 0.8,
            }}
            title={`Confidence: ${Math.round(confidence * 100)}%`}
          />
        )}
        {/* Correction dot */}
        {hasCorrections && (
          <div className="h-1.5 w-1.5 rounded-full bg-[#E91E63]" title="Has corrections" />
        )}
      </div>

      {/* Current frame indicator */}
      {isCurrentFrame && (
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white" />
      )}
    </div>
  );
};

export const Timeline: React.FC = () => {
  const {
    project,
    currentFrameIndex,
    setCurrentFrame,
    markAsKeyframe,
    canvas: canvasState,
    toggleOnionSkin,
  } = useChromaStore();

  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackFps, setPlaybackFps] = useState(24);
  const playIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; frameIndex: number } | null>(null);

  useEffect(() => {
    if (isPlaying && project) {
      let frameCount = currentFrameIndex;
      playIntervalRef.current = setInterval(() => {
        frameCount++;
        if (frameCount >= project.frames.length) {
          setIsPlaying(false);
          frameCount = 0;
        }
        setCurrentFrame(frameCount);
      }, 1000 / playbackFps);
    } else {
      if (playIntervalRef.current) clearInterval(playIntervalRef.current);
    }
    return () => { if (playIntervalRef.current) clearInterval(playIntervalRef.current); };
  }, [isPlaying, playbackFps, project, setCurrentFrame]);

  // Auto-scroll to current frame
  useEffect(() => {
    if (timelineRef.current) {
      const el = timelineRef.current;
      const targetScroll = currentFrameIndex * 37 - el.clientWidth / 2 + 18;
      el.scrollLeft = Math.max(0, targetScroll);
    }
  }, [currentFrameIndex]);

  const handleContextMenu = (e: React.MouseEvent, frameIndex: number) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, frameIndex });
  };

  if (!project) {
    return (
      <div className="flex h-full items-center justify-center text-[#333] text-sm">
        No project open
      </div>
    );
  }

  const totalDuration = project.frames.length / project.fps;
  const currentTime = currentFrameIndex / project.fps;

  return (
    <div className="flex h-full flex-col bg-[#181818] select-none" onClick={() => setContextMenu(null)}>
      {/* Toolbar row */}
      <div className="flex items-center gap-2 border-b border-[#111] px-2 py-1 flex-shrink-0">
        {/* Playback controls */}
        <button
          onClick={() => setCurrentFrame(0)}
          className="flex h-6 w-6 items-center justify-center rounded text-[#666] hover:bg-[#2a2a2a] hover:text-[#ccc]"
          title="Go to Start"
        >
          <SkipBackIcon />
        </button>
        <button
          onClick={() => setCurrentFrame(Math.max(0, currentFrameIndex - 1))}
          className="flex h-6 w-6 items-center justify-center rounded text-[#666] hover:bg-[#2a2a2a] hover:text-[#ccc]"
          title="Previous Frame (←)"
        >
          <PrevFrameIcon />
        </button>
        <button
          onClick={() => setIsPlaying((p) => !p)}
          className={`flex h-7 w-7 items-center justify-center rounded ${isPlaying ? 'bg-[#2a6ac8] text-white' : 'bg-[#2a2a2a] text-[#ccc] hover:bg-[#333]'}`}
          title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
        >
          {isPlaying ? <PauseIcon /> : <PlayIcon />}
        </button>
        <button
          onClick={() => { setIsPlaying(false); setCurrentFrame(0); }}
          className="flex h-6 w-6 items-center justify-center rounded text-[#666] hover:bg-[#2a2a2a] hover:text-[#ccc]"
          title="Stop"
        >
          <StopIcon />
        </button>
        <button
          onClick={() => setCurrentFrame(Math.min(project.frames.length - 1, currentFrameIndex + 1))}
          className="flex h-6 w-6 items-center justify-center rounded text-[#666] hover:bg-[#2a2a2a] hover:text-[#ccc]"
          title="Next Frame (→)"
        >
          <NextFrameIcon />
        </button>
        <button
          onClick={() => setCurrentFrame(project.frames.length - 1)}
          className="flex h-6 w-6 items-center justify-center rounded text-[#666] hover:bg-[#2a2a2a] hover:text-[#ccc]"
          title="Go to End"
        >
          <SkipForwardIcon />
        </button>

        {/* Separator */}
        <div className="h-4 w-px bg-[#2a2a2a]" />

        {/* Frame counter */}
        <div className="flex items-center gap-1 font-mono text-[11px]">
          <span className="text-[#fff] font-semibold">{(currentFrameIndex + 1).toString().padStart(3, '0')}</span>
          <span className="text-[#444]">/</span>
          <span className="text-[#555]">{project.frames.length.toString().padStart(3, '0')}</span>
          <span className="text-[#444] ml-1">
            {currentTime.toFixed(2)}s / {totalDuration.toFixed(2)}s
          </span>
        </div>

        {/* Separator */}
        <div className="h-4 w-px bg-[#2a2a2a]" />

        {/* FPS selector */}
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-[#555]">FPS:</span>
          <select
            value={playbackFps}
            onChange={(e) => setPlaybackFps(Number(e.target.value))}
            className="h-5 rounded bg-[#1e1e1e] border border-[#2a2a2a] px-1 text-[10px] text-[#888]"
          >
            <option value={8}>8</option>
            <option value={12}>12</option>
            <option value={24}>24</option>
            <option value={30}>30</option>
          </select>
        </div>

        {/* Separator */}
        <div className="h-4 w-px bg-[#2a2a2a]" />

        {/* Onion skin toggle */}
        <button
          onClick={toggleOnionSkin}
          className={`flex items-center gap-1 rounded px-2 py-0.5 text-[10px] transition-colors ${
            canvasState.showOnionSkin ? 'bg-[#1a3a6a] text-[#7ab4ff]' : 'text-[#555] hover:bg-[#2a2a2a] hover:text-[#888]'
          }`}
          title="Toggle Onion Skinning (O)"
        >
          <svg viewBox="0 0 16 16" width={10} height={10} fill="none" stroke="currentColor" strokeWidth={1.5}>
            <circle cx="8" cy="8" r="6" opacity="0.3" />
            <circle cx="8" cy="8" r="4" opacity="0.6" />
            <circle cx="8" cy="8" r="2" />
          </svg>
          Onion
        </button>

        <div className="flex-1" />

        {/* Stats */}
        <div className="flex items-center gap-2 text-[10px] text-[#444]">
          <span>{project.frames.filter((f) => f.isKeyframe).length} keyframes</span>
          <span className="text-[#2ECC71]">{project.frames.filter((f) => f.isColorized).length} colorized</span>
          <span className="text-[#555]">{project.frames.filter((f) => !f.isColorized).length} pending</span>
        </div>
      </div>

      {/* Timeline track */}
      <div className="flex flex-1 overflow-hidden">
        {/* Track label */}
        <div className="flex-shrink-0 w-24 border-r border-[#111] bg-[#161616]">
          <div className="flex h-full flex-col">
            {/* Header */}
            <div className="flex items-center justify-between px-2 py-1 border-b border-[#111]">
              <span className="text-[10px] text-[#444] font-medium">Tracks</span>
              <button className="text-[#333] hover:text-[#666] text-[10px]">+</button>
            </div>
            {/* Track rows */}
            {['Line Art', 'AI Color', 'Corrections', 'BG'].map((name) => (
              <div key={name} className="flex items-center px-2 py-1 border-b border-[#111] hover:bg-[#1e1e1e]">
                <span className="text-[10px] text-[#555] truncate">{name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Scrollable frame strip */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {/* Time ruler */}
          <div className="flex-shrink-0 border-b border-[#111] bg-[#161616] overflow-hidden">
            <div className="flex" style={{ height: 18 }}>
              {project.frames.map((_, i) => (
                <div
                  key={i}
                  className="flex-shrink-0 flex items-center justify-center border-r border-[#111]"
                  style={{ width: 36 }}
                >
                  {i % 6 === 0 && (
                    <span className="text-[8px] text-[#444] font-mono">
                      {(i / project.fps).toFixed(1)}s
                    </span>
                  )}
                  {i % 6 !== 0 && i % 2 === 0 && (
                    <div className="h-1.5 w-px bg-[#2a2a2a]" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Frame cells */}
          <div
            ref={timelineRef}
            className="flex-1 overflow-x-auto overflow-y-hidden"
            style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}
          >
            <div className="flex h-full">
              {project.frames.map((frame) => (
                <FrameCell
                  key={frame.id}
                  frameIndex={frame.index}
                  isCurrentFrame={frame.index === currentFrameIndex}
                  isKeyframe={frame.isKeyframe}
                  isColorized={frame.isColorized}
                  hasCorrections={frame.hasCorrections}
                  confidence={frame.confidence}
                  onClick={() => setCurrentFrame(frame.index)}
                  onDoubleClick={() => markAsKeyframe(frame.index)}
                  onContextMenu={(e) => handleContextMenu(e, frame.index)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Context menu */}
      {contextMenu && (
        <div
          className="fixed z-50 min-w-40 rounded border border-[#3a3a3a] bg-[#1e1e1e] py-1 shadow-2xl"
          style={{ left: contextMenu.x, top: contextMenu.y - 100 }}
        >
          {[
            { label: 'Toggle Keyframe', action: () => markAsKeyframe(contextMenu.frameIndex) },
            { label: 'Go to Frame', action: () => setCurrentFrame(contextMenu.frameIndex) },
            { separator: true },
            { label: 'Colorize This Frame', action: () => {} },
            { label: 'Clear Colorization', action: () => {} },
            { separator: true },
            { label: 'Learn from Correction', action: () => {} },
            { label: 'Propagate Forward from Here', action: () => {} },
            { separator: true },
            { label: 'Insert Frame Before', action: () => {} },
            { label: 'Insert Frame After', action: () => {} },
            { label: 'Delete Frame', action: () => {} },
          ].map((item, i) =>
            item.separator ? (
              <div key={i} className="my-1 border-t border-[#2a2a2a]" />
            ) : (
              <button
                key={i}
                className="w-full px-3 py-1 text-left text-[12px] text-[#ccc] hover:bg-[#2a6ac8] hover:text-white"
                onClick={() => { item.action?.(); setContextMenu(null); }}
              >
                {item.label}
              </button>
            )
          )}
        </div>
      )}
    </div>
  );
};
