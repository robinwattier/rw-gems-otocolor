/**
 * ChromaFlow — Export Dialog
 * Professional export options: PNG sequence, PSD, MP4, EXR
 */

import React, { useState } from 'react';
import { useChromaStore } from '../store/chromaStore';

type ExportFormat = 'png-sequence' | 'mp4' | 'psd' | 'exr' | 'gif' | 'webm';

interface ExportOption {
  id: ExportFormat;
  name: string;
  description: string;
  icon: string;
  pro?: boolean;
}

const EXPORT_OPTIONS: ExportOption[] = [
  { id: 'png-sequence', name: 'PNG Sequence + Alpha', description: 'Lossless frames with transparency, ideal for compositing', icon: '🖼' },
  { id: 'mp4', name: 'MP4 Video', description: 'H.264/H.265 compressed video via FFmpeg', icon: '🎬' },
  { id: 'psd', name: 'Multi-Layer PSD', description: 'Photoshop document with all layers preserved', icon: '📦', pro: true },
  { id: 'exr', name: 'EXR Sequence', description: '32-bit HDR sequence for VFX pipeline integration', icon: '✨', pro: true },
  { id: 'gif', name: 'Animated GIF', description: 'Optimized GIF with palette quantization', icon: '🌀' },
  { id: 'webm', name: 'WebM / VP9', description: 'Web-optimized transparent video with alpha', icon: '🌐' },
];

export const ExportDialog: React.FC = () => {
  const { project, setShowExportDialog } = useChromaStore();
  const [selectedFormat, setSelectedFormat] = useState<ExportFormat>('png-sequence');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportComplete, setExportComplete] = useState(false);

  const [settings, setSettings] = useState({
    width: project?.width ?? 1920,
    height: project?.height ?? 1080,
    fps: project?.fps ?? 24,
    quality: 95,
    includeAlpha: true,
    includeAllLayers: true,
    startFrame: 0,
    endFrame: (project?.frames.length ?? 1) - 1,
    outputPath: '~/Desktop/ChromaFlow_Export/',
    codec: 'h264',
    bitrate: 8000,
    colorProfile: 'sRGB',
  });

  if (!project) return null;

  const handleExport = () => {
    setIsExporting(true);
    setExportProgress(0);
    setExportComplete(false);

    // Simulate export
    let pct = 0;
    const interval = setInterval(() => {
      pct += Math.random() * 12;
      if (pct >= 100) {
        clearInterval(interval);
        setExportProgress(100);
        setIsExporting(false);
        setExportComplete(true);
      } else {
        setExportProgress(pct);
      }
    }, 120);
  };

  const colorized = project.frames.filter((f) => f.isColorized).length;
  const selectedOption = EXPORT_OPTIONS.find((o) => o.id === selectedFormat)!;
  const frameRange = settings.endFrame - settings.startFrame + 1;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-80 backdrop-blur-sm">
      <div className="w-[700px] max-h-[90vh] rounded-xl border border-[#2a2a2a] bg-[#1a1a1a] shadow-2xl overflow-hidden flex flex-col">

        {/* Title bar */}
        <div className="flex items-center justify-between border-b border-[#111] bg-[#161616] px-5 py-3 flex-shrink-0">
          <div className="flex items-center gap-2">
            <svg viewBox="0 0 20 20" width={16} height={16} fill="none" stroke="#888" strokeWidth={1.5}>
              <path d="M4 14l2-2 3 3 5-8" />
              <rect x="2" y="2" width="16" height="16" rx="2" />
            </svg>
            <span className="text-[14px] font-semibold text-[#ccc]">Export</span>
            <span className="text-[11px] text-[#555]">— {project.name}</span>
          </div>
          <button
            onClick={() => setShowExportDialog(false)}
            className="text-[#555] hover:text-[#ccc] transition-colors"
          >
            <svg viewBox="0 0 16 16" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.5}>
              <path d="M4 4l8 8M12 4l-8 8" />
            </svg>
          </button>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Format selector */}
          <div className="w-52 flex-shrink-0 border-r border-[#111] overflow-y-auto" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>
            {EXPORT_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                onClick={() => setSelectedFormat(opt.id)}
                className={`w-full flex items-start gap-3 px-3 py-3 text-left border-b border-[#111] transition-colors ${
                  selectedFormat === opt.id
                    ? 'bg-[#1a3a6a]'
                    : 'hover:bg-[#1e1e1e]'
                }`}
              >
                <span className="text-lg leading-none flex-shrink-0">{opt.icon}</span>
                <div>
                  <div className={`text-[12px] font-medium flex items-center gap-1 ${selectedFormat === opt.id ? 'text-[#7ab4ff]' : 'text-[#888]'}`}>
                    {opt.name}
                    {opt.pro && (
                      <span className="rounded bg-[#533483] px-1 text-[8px] text-[#ccc]">PRO</span>
                    )}
                  </div>
                  <div className="text-[10px] text-[#444] mt-0.5 leading-tight">{opt.description}</div>
                </div>
              </button>
            ))}
          </div>

          {/* Settings panel */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 #111' }}>

            {/* Selected format header */}
            <div className="flex items-center gap-2">
              <span className="text-2xl">{selectedOption.icon}</span>
              <div>
                <h3 className="text-[14px] font-semibold text-[#ccc]">{selectedOption.name}</h3>
                <p className="text-[11px] text-[#555]">{selectedOption.description}</p>
              </div>
            </div>

            {/* Frame range */}
            <div className="space-y-2">
              <h4 className="text-[11px] font-semibold text-[#666] uppercase tracking-wider">Frame Range</h4>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-[#555] mb-1 block">Start Frame</label>
                  <input
                    type="number"
                    min={0}
                    max={project.frames.length - 1}
                    value={settings.startFrame + 1}
                    onChange={(e) => setSettings({ ...settings, startFrame: Math.max(0, Number(e.target.value) - 1) })}
                    className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#555] mb-1 block">End Frame</label>
                  <input
                    type="number"
                    min={1}
                    max={project.frames.length}
                    value={settings.endFrame + 1}
                    onChange={(e) => setSettings({ ...settings, endFrame: Math.min(project.frames.length - 1, Number(e.target.value) - 1) })}
                    className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#555] mb-1 block">Frame Count</label>
                  <div className="rounded border border-[#2a2a2a] bg-[#161616] px-2 py-1.5 text-[11px] text-[#888] font-mono">{frameRange}</div>
                </div>
              </div>
              <div className="flex gap-2">
                {['All Frames', 'Colorized Only', 'Selection'].map((opt) => (
                  <button
                    key={opt}
                    className="rounded border border-[#2a2a2a] px-2 py-0.5 text-[10px] text-[#555] hover:border-[#2a6ac8] hover:text-[#7ab4ff] transition-colors"
                    onClick={() => {
                      if (opt === 'All Frames') setSettings({ ...settings, startFrame: 0, endFrame: project.frames.length - 1 });
                      if (opt === 'Colorized Only') setSettings({ ...settings, startFrame: 0, endFrame: colorized - 1 });
                    }}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Resolution */}
            <div className="space-y-2">
              <h4 className="text-[11px] font-semibold text-[#666] uppercase tracking-wider">Resolution</h4>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-[#555] mb-1 block">Width</label>
                  <input
                    type="number"
                    value={settings.width}
                    onChange={(e) => setSettings({ ...settings, width: Number(e.target.value) })}
                    className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#555] mb-1 block">Height</label>
                  <input
                    type="number"
                    value={settings.height}
                    onChange={(e) => setSettings({ ...settings, height: Number(e.target.value) })}
                    className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#555] mb-1 block">Preset</label>
                  <select className="w-full rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-1.5 text-[10px] text-[#888] outline-none">
                    <option>1920×1080 (FHD)</option>
                    <option>3840×2160 (4K)</option>
                    <option>1280×720 (HD)</option>
                    <option>Custom</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Format-specific settings */}
            {selectedFormat === 'mp4' && (
              <div className="space-y-2">
                <h4 className="text-[11px] font-semibold text-[#666] uppercase tracking-wider">Video Settings</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-[#555] mb-1 block">Codec</label>
                    <select
                      value={settings.codec}
                      onChange={(e) => setSettings({ ...settings, codec: e.target.value })}
                      className="w-full rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-1.5 text-[10px] text-[#888] outline-none"
                    >
                      <option value="h264">H.264 (AVC)</option>
                      <option value="h265">H.265 (HEVC)</option>
                      <option value="prores">Apple ProRes 4444</option>
                      <option value="dnxhr">Avid DNxHR</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-[#555] mb-1 block">Bitrate</label>
                    <input
                      type="number"
                      value={settings.bitrate}
                      onChange={(e) => setSettings({ ...settings, bitrate: Number(e.target.value) })}
                      className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#555] mb-1 block">Frame Rate</label>
                    <select className="w-full rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-1.5 text-[10px] text-[#888] outline-none">
                      <option>24 fps</option>
                      <option>25 fps</option>
                      <option>30 fps</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-[#555] mb-1 block">Color Space</label>
                    <select className="w-full rounded border border-[#2a2a2a] bg-[#111] px-1.5 py-1.5 text-[10px] text-[#888] outline-none">
                      <option>sRGB (Rec.709)</option>
                      <option>DCI-P3</option>
                      <option>Rec.2020</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {(selectedFormat === 'png-sequence' || selectedFormat === 'exr') && (
              <div className="space-y-2">
                <h4 className="text-[11px] font-semibold text-[#666] uppercase tracking-wider">Sequence Settings</h4>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[#666]">Include Alpha Channel</span>
                  <div
                    className={`h-4 w-7 rounded-full relative cursor-pointer transition-colors ${settings.includeAlpha ? 'bg-[#2a6ac8]' : 'bg-[#2a2a2a]'}`}
                    onClick={() => setSettings({ ...settings, includeAlpha: !settings.includeAlpha })}
                  >
                    <div className={`absolute top-0.5 h-3 w-3 rounded-full bg-white shadow transition-transform ${settings.includeAlpha ? 'right-0.5' : 'left-0.5'}`} />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[#666]">Export All Layers Separately</span>
                  <div
                    className={`h-4 w-7 rounded-full relative cursor-pointer transition-colors ${settings.includeAllLayers ? 'bg-[#2a6ac8]' : 'bg-[#2a2a2a]'}`}
                    onClick={() => setSettings({ ...settings, includeAllLayers: !settings.includeAllLayers })}
                  >
                    <div className={`absolute top-0.5 h-3 w-3 rounded-full bg-white shadow transition-transform ${settings.includeAllLayers ? 'right-0.5' : 'left-0.5'}`} />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-[#555] mb-1 block">Filename Pattern</label>
                  <input
                    defaultValue="{project_name}_{frame:04d}.png"
                    className="w-full rounded border border-[#2a2a2a] bg-[#111] px-2 py-1.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                  />
                </div>
              </div>
            )}

            {/* Output path */}
            <div className="space-y-1">
              <label className="text-[10px] text-[#555]">Output Path</label>
              <div className="flex gap-2">
                <input
                  value={settings.outputPath}
                  onChange={(e) => setSettings({ ...settings, outputPath: e.target.value })}
                  className="flex-1 rounded border border-[#2a2a2a] bg-[#111] px-2 py-1.5 text-[11px] text-[#ccc] font-mono outline-none focus:border-[#2a6ac8]"
                />
                <button className="rounded border border-[#2a2a2a] px-3 text-[10px] text-[#555] hover:border-[#2a6ac8] hover:text-[#7ab4ff] transition-colors">
                  Browse…
                </button>
              </div>
            </div>

            {/* Summary */}
            <div className="rounded border border-[#2a2a2a] bg-[#161616] p-3 text-[10px] text-[#555] space-y-1">
              <div className="flex justify-between">
                <span>Format:</span><span className="text-[#888]">{selectedOption.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Frames:</span><span className="text-[#888] font-mono">{frameRange} ({colorized} colorized)</span>
              </div>
              <div className="flex justify-between">
                <span>Resolution:</span><span className="text-[#888] font-mono">{settings.width}×{settings.height}</span>
              </div>
              <div className="flex justify-between">
                <span>Output:</span><span className="text-[#888] truncate ml-4">{settings.outputPath}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#111] bg-[#161616] px-5 py-3 flex-shrink-0">
          {isExporting ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#F39C12] animate-pulse">Exporting…</span>
                <span className="text-[#888] font-mono">{Math.round(exportProgress)}%</span>
              </div>
              <div className="h-2 w-full rounded-full bg-[#1a1a1a] overflow-hidden">
                <div
                  className="h-full rounded-full bg-[#2a6ac8] transition-all duration-200"
                  style={{ width: `${exportProgress}%` }}
                />
              </div>
            </div>
          ) : exportComplete ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#2ECC71] text-[12px]">
                <svg viewBox="0 0 16 16" width={14} height={14} fill="none" stroke="currentColor" strokeWidth={1.5}>
                  <circle cx="8" cy="8" r="6" />
                  <path d="M5 8l2 2 4-4" />
                </svg>
                Export complete! {frameRange} frames exported.
              </div>
              <div className="flex gap-2">
                <button className="rounded border border-[#2a2a2a] px-3 py-1.5 text-[11px] text-[#666] hover:text-[#ccc] transition-colors">
                  Open Folder
                </button>
                <button
                  onClick={() => setShowExportDialog(false)}
                  className="rounded bg-[#2a6ac8] px-4 py-1.5 text-[11px] text-white hover:bg-[#3a7ad8] transition-colors"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <div className="text-[11px] text-[#444]">
                Est. size: ~{Math.round(frameRange * (selectedFormat === 'exr' ? 8 : selectedFormat === 'mp4' ? 0.1 : 2))} MB
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowExportDialog(false)}
                  className="rounded border border-[#2a2a2a] px-4 py-1.5 text-[12px] text-[#666] hover:text-[#ccc] transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleExport}
                  className="rounded bg-[#2a6ac8] px-5 py-1.5 text-[12px] font-semibold text-white hover:bg-[#3a7ad8] transition-colors"
                >
                  Export {selectedOption.name}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
