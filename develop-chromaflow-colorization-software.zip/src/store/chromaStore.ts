/**
 * ChromaFlow — Global Application State (Zustand)
 * Manages all application state: project, frames, palette, UI panels, AI workflow
 */

import { create } from 'zustand';

// ─────────────────────────────────────────────
// Types & Interfaces
// ─────────────────────────────────────────────

export type WorkflowPhase = 'ingestion' | 'propagation' | 'refinement';
export type PanelId = 'timeline' | 'palette' | 'layers' | 'reference' | 'properties' | 'history';
export type ToolId =
  | 'select'
  | 'brush'
  | 'fill'
  | 'eyedropper'
  | 'eraser'
  | 'pan'
  | 'zoom'
  | 'lasso'
  | 'smartFill'
  | 'semanticTag';

export interface ColorSwatch {
  id: string;
  hex: string;
  label: string;
  tag: string;
  category: string;
  usageCount: number;
}

export interface ColorPalette {
  id: string;
  name: string;
  characterName: string;
  swatches: ColorSwatch[];
  isActive: boolean;
  createdAt: number;
}

export interface AnimationFrame {
  id: string;
  index: number;
  imageUrl: string | null;
  colorLayerUrl: string | null;
  isKeyframe: boolean;
  isColorized: boolean;
  hasCorrections: boolean;
  semanticLabels: SemanticLabel[];
  thumbnail: string | null;
  confidence: number; // 0-1 AI confidence
}

export interface SemanticLabel {
  id: string;
  frameId: string;
  colorHex: string;
  colorTag: string;
  regionMask: number[]; // flat pixel indices
  boundingBox: { x: number; y: number; w: number; h: number };
  confidence: number;
}

export interface Layer {
  id: string;
  name: string;
  type: 'lineart' | 'color' | 'correction' | 'reference' | 'group';
  visible: boolean;
  locked: boolean;
  opacity: number;
  blendMode: string;
  color: string;
}

export interface Project {
  id: string;
  name: string;
  fps: number;
  width: number;
  height: number;
  createdAt: number;
  modifiedAt: number;
  frames: AnimationFrame[];
  palettes: ColorPalette[];
  activePaletteId: string | null;
}

export interface AIProgress {
  isRunning: boolean;
  phase: 'analyzing' | 'segmenting' | 'colorizing' | 'propagating' | 'refining' | 'idle';
  currentFrame: number;
  totalFrames: number;
  message: string;
  percentage: number;
  modelStatus: {
    sam2: 'loading' | 'ready' | 'error' | 'idle';
    opticalFlow: 'loading' | 'ready' | 'error' | 'idle';
    fewShot: 'loading' | 'ready' | 'error' | 'idle';
  };
}

export interface CanvasState {
  zoom: number;
  panX: number;
  panY: number;
  rotation: number;
  showGrid: boolean;
  showOnionSkin: boolean;
  onionSkinFrames: number;
  onionSkinOpacity: number;
}

export interface HistoryEntry {
  id: string;
  label: string;
  timestamp: number;
  frameIndex: number;
}

// ─────────────────────────────────────────────
// Store Interface
// ─────────────────────────────────────────────

interface ChromaStore {
  // Project
  project: Project | null;
  createProject: (name: string, width: number, height: number, fps: number) => void;
  loadDemoProject: () => void;

  // Workflow
  currentPhase: WorkflowPhase;
  setPhase: (phase: WorkflowPhase) => void;

  // Frames & Timeline
  currentFrameIndex: number;
  setCurrentFrame: (index: number) => void;
  addFrame: (imageUrl: string) => void;
  markAsKeyframe: (frameIndex: number) => void;
  setFrameColorized: (frameIndex: number, colorUrl: string, confidence: number) => void;

  // Canvas
  canvas: CanvasState;
  setZoom: (zoom: number) => void;
  setPan: (x: number, y: number) => void;
  setRotation: (deg: number) => void;
  toggleGrid: () => void;
  toggleOnionSkin: () => void;

  // Tools
  activeTool: ToolId;
  setTool: (tool: ToolId) => void;
  brushSize: number;
  setBrushSize: (size: number) => void;
  brushOpacity: number;
  setBrushOpacity: (opacity: number) => void;

  // Colors
  foregroundColor: string;
  backgroundColor: string;
  setForegroundColor: (hex: string) => void;
  setBackgroundColor: (hex: string) => void;
  colorHistory: string[];
  addColorToHistory: (hex: string) => void;

  // Palette
  activePalette: ColorPalette | null;
  setActivePalette: (id: string) => void;
  addSwatch: (paletteId: string, swatch: Omit<ColorSwatch, 'id' | 'usageCount'>) => void;
  updateSwatch: (paletteId: string, swatchId: string, updates: Partial<ColorSwatch>) => void;
  deleteSwatch: (paletteId: string, swatchId: string) => void;
  createPalette: (name: string, characterName: string) => void;

  // Layers
  layers: Layer[];
  activeLayerId: string | null;
  setActiveLayer: (id: string) => void;
  toggleLayerVisibility: (id: string) => void;
  setLayerOpacity: (id: string, opacity: number) => void;

  // Panels
  openPanels: PanelId[];
  togglePanel: (panel: PanelId) => void;

  // AI Engine
  aiProgress: AIProgress;
  startPropagation: () => void;
  cancelPropagation: () => void;
  learnFromCorrection: (frameIndex: number) => void;

  // History
  undoHistory: HistoryEntry[];
  addHistoryEntry: (label: string, frameIndex: number) => void;
  undo: () => void;
  redo: () => void;

  // UI
  showWelcome: boolean;
  setShowWelcome: (show: boolean) => void;
  showExportDialog: boolean;
  setShowExportDialog: (show: boolean) => void;
  showPreferences: boolean;
  setShowPreferences: (show: boolean) => void;
  activeRightPanel: string;
  setActiveRightPanel: (panel: string) => void;
  statusMessage: string;
  setStatusMessage: (msg: string) => void;
}

// ─────────────────────────────────────────────
// Demo Data Generators
// ─────────────────────────────────────────────

const DEMO_PALETTES: ColorPalette[] = [
  {
    id: 'pal-hero',
    name: 'Hero Character',
    characterName: 'Kaito',
    isActive: true,
    createdAt: Date.now(),
    swatches: [
      { id: 'sw-1', hex: '#FF5733', label: 'Veste Héros', tag: 'jacket_main', category: 'clothing', usageCount: 42 },
      { id: 'sw-2', hex: '#C0392B', label: 'Veste Ombre', tag: 'jacket_shadow', category: 'clothing', usageCount: 38 },
      { id: 'sw-3', hex: '#FF8C69', label: 'Veste Lumière', tag: 'jacket_highlight', category: 'clothing', usageCount: 31 },
      { id: 'sw-4', hex: '#2E8B57', label: 'Peau Claire', tag: 'skin_base', category: 'skin', usageCount: 89 },
      { id: 'sw-5', hex: '#1F6B3E', label: 'Peau Ombre', tag: 'skin_shadow', category: 'skin', usageCount: 72 },
      { id: 'sw-6', hex: '#5EBF87', label: 'Peau Lumière', tag: 'skin_highlight', category: 'skin', usageCount: 61 },
      { id: 'sw-7', hex: '#1A1A2E', label: 'Cheveux Base', tag: 'hair_base', category: 'hair', usageCount: 95 },
      { id: 'sw-8', hex: '#16213E', label: 'Cheveux Ombre', tag: 'hair_shadow', category: 'hair', usageCount: 80 },
      { id: 'sw-9', hex: '#4A4A8A', label: 'Cheveux Reflet', tag: 'hair_highlight', category: 'hair', usageCount: 55 },
      { id: 'sw-10', hex: '#ECF0F1', label: 'Yeux Blanc', tag: 'eyes_white', category: 'face', usageCount: 93 },
      { id: 'sw-11', hex: '#3498DB', label: 'Yeux Iris', tag: 'eyes_iris', category: 'face', usageCount: 91 },
      { id: 'sw-12', hex: '#2C3E50', label: 'Pantalon', tag: 'pants_base', category: 'clothing', usageCount: 78 },
    ],
  },
  {
    id: 'pal-bg',
    name: 'Scene Background',
    characterName: 'Scene 01 — Dusk City',
    isActive: false,
    createdAt: Date.now() - 86400000,
    swatches: [
      { id: 'sw-bg-1', hex: '#FF6B35', label: 'Ciel Crépuscule', tag: 'sky_dusk', category: 'sky', usageCount: 20 },
      { id: 'sw-bg-2', hex: '#F7C59F', label: 'Nuages Chauds', tag: 'clouds_warm', category: 'sky', usageCount: 18 },
      { id: 'sw-bg-3', hex: '#2D2D44', label: 'Bâtiments Nuit', tag: 'buildings_night', category: 'architecture', usageCount: 30 },
      { id: 'sw-bg-4', hex: '#FFD700', label: 'Fenêtres Lumières', tag: 'windows_light', category: 'architecture', usageCount: 25 },
      { id: 'sw-bg-5', hex: '#1A1A2E', label: 'Sol Asphalte', tag: 'ground_asphalt', category: 'ground', usageCount: 40 },
      { id: 'sw-bg-6', hex: '#45B7D1', label: 'Néon Bleu', tag: 'neon_blue', category: 'fx', usageCount: 15 },
    ],
  },
];

const generateDemoFrames = (): AnimationFrame[] => {
  const frames: AnimationFrame[] = [];
  for (let i = 0; i < 24; i++) {
    frames.push({
      id: `frame-${i}`,
      index: i,
      imageUrl: null,
      colorLayerUrl: null,
      isKeyframe: i === 0 || i === 6 || i === 12 || i === 18 || i === 23,
      isColorized: i < 8,
      hasCorrections: i === 3 || i === 5,
      semanticLabels: [],
      thumbnail: null,
      confidence: i < 8 ? 0.85 + Math.random() * 0.14 : 0,
    });
  }
  return frames;
};

// ─────────────────────────────────────────────
// Default Layers
// ─────────────────────────────────────────────

const DEFAULT_LAYERS: Layer[] = [
  { id: 'lay-lineart', name: 'Line Art', type: 'lineart', visible: true, locked: true, opacity: 100, blendMode: 'multiply', color: '#4FC3F7' },
  { id: 'lay-color', name: 'AI Color', type: 'color', visible: true, locked: false, opacity: 100, blendMode: 'normal', color: '#A5D6A7' },
  { id: 'lay-correction', name: 'Corrections', type: 'correction', visible: true, locked: false, opacity: 100, blendMode: 'normal', color: '#FFCC80' },
  { id: 'lay-shadow', name: 'Shadows', type: 'color', visible: true, locked: false, opacity: 75, blendMode: 'multiply', color: '#CE93D8' },
  { id: 'lay-highlight', name: 'Highlights', type: 'color', visible: true, locked: false, opacity: 60, blendMode: 'screen', color: '#F48FB1' },
  { id: 'lay-bg', name: 'Background', type: 'color', visible: true, locked: false, opacity: 100, blendMode: 'normal', color: '#90CAF9' },
];

// ─────────────────────────────────────────────
// Store Implementation
// ─────────────────────────────────────────────

let propagationInterval: ReturnType<typeof setInterval> | null = null;

export const useChromaStore = create<ChromaStore>((set, get) => ({
  // ── Project ──
  project: null,

  createProject: (name, width, height, fps) => {
    const project: Project = {
      id: `proj-${Date.now()}`,
      name,
      fps,
      width,
      height,
      createdAt: Date.now(),
      modifiedAt: Date.now(),
      frames: generateDemoFrames(),
      palettes: DEMO_PALETTES,
      activePaletteId: 'pal-hero',
    };
    set({
      project,
      activePalette: DEMO_PALETTES[0],
      showWelcome: false,
      currentPhase: 'ingestion',
      statusMessage: `Project "${name}" created — ${width}×${height} @ ${fps}fps`,
    });
  },

  loadDemoProject: () => {
    const project: Project = {
      id: 'demo-project',
      name: 'Kaito — Episode 3',
      fps: 24,
      width: 1920,
      height: 1080,
      createdAt: Date.now() - 3600000,
      modifiedAt: Date.now(),
      frames: generateDemoFrames(),
      palettes: DEMO_PALETTES,
      activePaletteId: 'pal-hero',
    };
    set({
      project,
      activePalette: DEMO_PALETTES[0],
      showWelcome: false,
      currentPhase: 'ingestion',
      statusMessage: 'Demo project loaded — 24 frames @ 24fps',
    });
  },

  // ── Workflow ──
  currentPhase: 'ingestion',
  setPhase: (phase) => set({ currentPhase: phase }),

  // ── Frames ──
  currentFrameIndex: 0,
  setCurrentFrame: (index) => set({ currentFrameIndex: index }),

  addFrame: (imageUrl) => {
    const { project } = get();
    if (!project) return;
    const newFrame: AnimationFrame = {
      id: `frame-${Date.now()}`,
      index: project.frames.length,
      imageUrl,
      colorLayerUrl: null,
      isKeyframe: false,
      isColorized: false,
      hasCorrections: false,
      semanticLabels: [],
      thumbnail: null,
      confidence: 0,
    };
    set({ project: { ...project, frames: [...project.frames, newFrame] } });
  },

  markAsKeyframe: (frameIndex) => {
    const { project } = get();
    if (!project) return;
    const frames = project.frames.map((f) =>
      f.index === frameIndex ? { ...f, isKeyframe: !f.isKeyframe } : f
    );
    set({ project: { ...project, frames } });
  },

  setFrameColorized: (frameIndex, colorUrl, confidence) => {
    const { project } = get();
    if (!project) return;
    const frames = project.frames.map((f) =>
      f.index === frameIndex ? { ...f, isColorized: true, colorLayerUrl: colorUrl, confidence } : f
    );
    set({ project: { ...project, frames } });
  },

  // ── Canvas ──
  canvas: {
    zoom: 1,
    panX: 0,
    panY: 0,
    rotation: 0,
    showGrid: false,
    showOnionSkin: true,
    onionSkinFrames: 2,
    onionSkinOpacity: 0.3,
  },

  setZoom: (zoom) => set((s) => ({ canvas: { ...s.canvas, zoom: Math.max(0.05, Math.min(32, zoom)) } })),
  setPan: (x, y) => set((s) => ({ canvas: { ...s.canvas, panX: x, panY: y } })),
  setRotation: (deg) => set((s) => ({ canvas: { ...s.canvas, rotation: deg } })),
  toggleGrid: () => set((s) => ({ canvas: { ...s.canvas, showGrid: !s.canvas.showGrid } })),
  toggleOnionSkin: () => set((s) => ({ canvas: { ...s.canvas, showOnionSkin: !s.canvas.showOnionSkin } })),

  // ── Tools ──
  activeTool: 'select',
  setTool: (tool) => set({ activeTool: tool }),
  brushSize: 12,
  setBrushSize: (size) => set({ brushSize: size }),
  brushOpacity: 100,
  setBrushOpacity: (opacity) => set({ brushOpacity: opacity }),

  // ── Colors ──
  foregroundColor: '#FF5733',
  backgroundColor: '#1A1A2E',
  colorHistory: ['#FF5733', '#2E8B57', '#1A1A2E', '#3498DB', '#ECF0F1', '#FFD700', '#C0392B', '#9B59B6'],

  setForegroundColor: (hex) => {
    get().addColorToHistory(hex);
    set({ foregroundColor: hex });
  },
  setBackgroundColor: (hex) => set({ backgroundColor: hex }),
  addColorToHistory: (hex) => {
    const history = get().colorHistory.filter((c) => c !== hex);
    set({ colorHistory: [hex, ...history].slice(0, 24) });
  },

  // ── Palette ──
  activePalette: DEMO_PALETTES[0],

  setActivePalette: (id) => {
    const { project } = get();
    if (!project) return;
    const palette = project.palettes.find((p) => p.id === id) ?? null;
    set({ activePalette: palette });
  },

  addSwatch: (paletteId, swatch) => {
    const { project } = get();
    if (!project) return;
    const newSwatch: ColorSwatch = { ...swatch, id: `sw-${Date.now()}`, usageCount: 0 };
    const palettes = project.palettes.map((p) =>
      p.id === paletteId ? { ...p, swatches: [...p.swatches, newSwatch] } : p
    );
    set({ project: { ...project, palettes } });
  },

  updateSwatch: (paletteId, swatchId, updates) => {
    const { project } = get();
    if (!project) return;
    const palettes = project.palettes.map((p) =>
      p.id === paletteId
        ? { ...p, swatches: p.swatches.map((s) => (s.id === swatchId ? { ...s, ...updates } : s)) }
        : p
    );
    set({ project: { ...project, palettes } });
  },

  deleteSwatch: (paletteId, swatchId) => {
    const { project } = get();
    if (!project) return;
    const palettes = project.palettes.map((p) =>
      p.id === paletteId ? { ...p, swatches: p.swatches.filter((s) => s.id !== swatchId) } : p
    );
    set({ project: { ...project, palettes } });
  },

  createPalette: (name, characterName) => {
    const { project } = get();
    if (!project) return;
    const newPalette: ColorPalette = {
      id: `pal-${Date.now()}`,
      name,
      characterName,
      swatches: [],
      isActive: false,
      createdAt: Date.now(),
    };
    set({ project: { ...project, palettes: [...project.palettes, newPalette] } });
  },

  // ── Layers ──
  layers: DEFAULT_LAYERS,
  activeLayerId: 'lay-color',
  setActiveLayer: (id) => set({ activeLayerId: id }),
  toggleLayerVisibility: (id) =>
    set((s) => ({
      layers: s.layers.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l)),
    })),
  setLayerOpacity: (id, opacity) =>
    set((s) => ({
      layers: s.layers.map((l) => (l.id === id ? { ...l, opacity } : l)),
    })),

  // ── Panels ──
  openPanels: ['timeline', 'palette', 'layers'],
  togglePanel: (panel) =>
    set((s) => ({
      openPanels: s.openPanels.includes(panel)
        ? s.openPanels.filter((p) => p !== panel)
        : [...s.openPanels, panel],
    })),

  // ── AI Engine ──
  aiProgress: {
    isRunning: false,
    phase: 'idle',
    currentFrame: 0,
    totalFrames: 0,
    message: 'Ready',
    percentage: 0,
    modelStatus: { sam2: 'idle', opticalFlow: 'idle', fewShot: 'idle' },
  },

  startPropagation: () => {
    const { project } = get();
    if (!project) return;
    const uncolorized = project.frames.filter((f) => !f.isColorized);
    if (uncolorized.length === 0) return;

    // Simulate model loading phase
    set({
      currentPhase: 'propagation',
      aiProgress: {
        isRunning: true,
        phase: 'analyzing',
        currentFrame: 0,
        totalFrames: uncolorized.length,
        message: 'Initializing SAM 2 segmentation model...',
        percentage: 0,
        modelStatus: { sam2: 'loading', opticalFlow: 'loading', fewShot: 'loading' },
      },
    });

    const phases = [
      { phase: 'analyzing' as const, msg: 'SAM 2 analyzing line art structure...', pct: 5, delay: 600 },
      { phase: 'segmenting' as const, msg: 'Optical flow estimation (RAFT)...', pct: 12, delay: 500 },
      { phase: 'segmenting' as const, msg: 'Building semantic region map...', pct: 18, delay: 700 },
      { phase: 'colorizing' as const, msg: 'Few-shot learning from keyframes...', pct: 24, delay: 800 },
      { phase: 'colorizing' as const, msg: 'Applying palette enforcement rules...', pct: 30, delay: 400 },
      { phase: 'propagating' as const, msg: 'Propagating colors with temporal consistency...', pct: 35, delay: 300 },
    ];

    let phaseIndex = 0;
    let frameIndex = 0;

    const runPhases = () => {
      if (phaseIndex < phases.length) {
        const p = phases[phaseIndex];
        set((s) => ({
          aiProgress: {
            ...s.aiProgress,
            phase: p.phase,
            message: p.msg,
            percentage: p.pct,
            modelStatus: { sam2: 'ready', opticalFlow: 'ready', fewShot: 'ready' },
          },
        }));
        phaseIndex++;
        setTimeout(runPhases, p.delay);
        return;
      }

      // Frame-by-frame propagation
      if (frameIndex < uncolorized.length) {
        const frame = uncolorized[frameIndex];
        const framePct = 35 + Math.round(((frameIndex + 1) / uncolorized.length) * 65);
        set((s) => ({
          aiProgress: {
            ...s.aiProgress,
            phase: 'propagating',
            currentFrame: frameIndex + 1,
            totalFrames: uncolorized.length,
            message: `Colorizing frame ${frame.index + 1} / ${project.frames.length}...`,
            percentage: framePct,
          },
          project: s.project
            ? {
                ...s.project,
                frames: s.project.frames.map((f) =>
                  f.id === frame.id
                    ? { ...f, isColorized: true, confidence: 0.78 + Math.random() * 0.2 }
                    : f
                ),
              }
            : s.project,
        }));
        frameIndex++;
        setTimeout(runPhases, 180 + Math.random() * 100);
        return;
      }

      // Done
      set((s) => ({
        currentPhase: 'refinement',
        aiProgress: {
          ...s.aiProgress,
          isRunning: false,
          phase: 'idle',
          percentage: 100,
          message: `✓ Propagation complete — ${uncolorized.length} frames colorized`,
        },
        statusMessage: `Propagation complete — ${uncolorized.length} frames colorized`,
      }));
    };

    setTimeout(runPhases, 100);
  },

  cancelPropagation: () => {
    if (propagationInterval) {
      clearInterval(propagationInterval);
      propagationInterval = null;
    }
    set((s) => ({
      aiProgress: { ...s.aiProgress, isRunning: false, phase: 'idle', message: 'Cancelled' },
    }));
  },

  learnFromCorrection: (frameIndex) => {
    set((s) => ({
      aiProgress: {
        ...s.aiProgress,
        isRunning: true,
        phase: 'refining',
        currentFrame: frameIndex,
        message: `Learning from correction on frame ${frameIndex + 1}...`,
        percentage: 0,
      },
      statusMessage: 'Learning from correction...',
    }));
    // Simulate incremental learning
    let pct = 0;
    const interval = setInterval(() => {
      pct += Math.random() * 25;
      if (pct >= 100) {
        clearInterval(interval);
        set((s) => ({
          aiProgress: { ...s.aiProgress, isRunning: false, phase: 'idle', percentage: 100, message: '✓ Model updated from correction' },
          statusMessage: '✓ Model updated — correction propagated forward',
        }));
        return;
      }
      set((s) => ({ aiProgress: { ...s.aiProgress, percentage: Math.min(pct, 99) } }));
    }, 300);
  },

  // ── History ──
  undoHistory: [],
  addHistoryEntry: (label, frameIndex) => {
    const entry: HistoryEntry = { id: `hist-${Date.now()}`, label, timestamp: Date.now(), frameIndex };
    set((s) => ({ undoHistory: [entry, ...s.undoHistory].slice(0, 50) }));
  },
  undo: () => set((s) => ({ undoHistory: s.undoHistory.slice(1) })),
  redo: () => {},

  // ── UI ──
  showWelcome: true,
  setShowWelcome: (show) => set({ showWelcome: show }),
  showExportDialog: false,
  setShowExportDialog: (show) => set({ showExportDialog: show }),
  showPreferences: false,
  setShowPreferences: (show) => set({ showPreferences: show }),
  activeRightPanel: 'palette',
  setActiveRightPanel: (panel) => set({ activeRightPanel: panel }),
  statusMessage: 'ChromaFlow v1.0 — Ready',
  setStatusMessage: (msg) => set({ statusMessage: msg }),
}));
